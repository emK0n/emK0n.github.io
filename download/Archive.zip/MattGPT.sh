#!/bin/sh
echo "Starting Flask Service"
. /Users/mattkonwiser/AgenticProjectBeta/.venv/bin/activate
echo "Launching Curator"
python3 /Users/mattkonwiser/AgenticProjectBeta/app.py
echo "Done"