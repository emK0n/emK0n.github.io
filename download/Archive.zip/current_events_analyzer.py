#!/usr/bin/env python3
"""
Current Events Analyzer - SSL Certificate Fix
FIXED: SSL certificate verification issues on macOS
"""
import glob
import feedparser
import ollama
import json
import time
from datetime import datetime
from typing import List, Dict, Optional, Callable
from dataclasses import dataclass
import re
import os
import sqlite3
from contextlib import contextmanager
import ssl
import urllib.request

# FIX SSL certificate issues on macOS
ssl._create_default_https_context = ssl._create_unverified_context

@dataclass
class NewsSource:
    """Represents a news source with its RSS feed"""
    name: str
    url: str
    category: str

class TechBusinessEventsAnalyzer:
    def __init__(self, ollama_model: str = "granite3.2:8b", output_callback: Optional[Callable[[str, str], None]] = None, data_directory: str = "data"):
        self.ollama_model = ollama_model
        self.output_callback = output_callback
        self.data_directory = data_directory

        os.makedirs(self.data_directory, exist_ok=True)
        
        # Simplified, working RSS feeds
        self.news_sources = [
            # Working HTTP feeds (no SSL issues)
            NewsSource("BBC Technology", "http://feeds.bbci.co.uk/news/technology/rss.xml", "technology"),
            NewsSource("BBC Business", "http://feeds.bbci.co.uk/news/business/rss.xml", "business"),
            NewsSource("BBC World", "http://feeds.bbci.co.uk/news/world/rss.xml", "world"),
            
            # HTTPS feeds that should work with SSL fix
            NewsSource("TechCrunch", "https://techcrunch.com/feed/", "technology"),
            NewsSource("Ars Technica", "https://feeds.arstechnica.com/arstechnica/index", "technology"),
            NewsSource("The Verge", "https://www.theverge.com/rss/index.xml", "technology"),
            NewsSource("Engadget", "https://www.engadget.com/rss.xml", "technology"),
            
            # Alternative working feeds
            NewsSource("Hacker News", "https://hnrss.org/frontpage", "technology"),
            NewsSource("Slashdot", "http://rss.slashdot.org/Slashdot/slashdotMain", "technology"),
        ]
        
        # Tech/business keywords for filtering
        self.tech_business_keywords = [
            "ai", "artificial", "intelligence", "tech", "technology", "digital", "software", 
            "startup", "business", "company", "market", "crypto", "bitcoin", "apple", 
            "google", "microsoft", "amazon", "meta", "tesla", "nvidia", "investment",
            "funding", "ipo", "venture", "silicon", "valley", "innovation", "data"
        ]

    @contextmanager
    def get_db_connection(self, db_path: str):
        """Context manager for database connections"""
        conn = None
        try:
            conn = sqlite3.connect(db_path, timeout=30.0)
            conn.execute('PRAGMA journal_mode=WAL')
            yield conn
        except Exception as e:
            if conn:
                conn.rollback()
            raise
        finally:
            if conn:
                conn.close()
    
    def _log(self, message: str, message_type: str = "info"):
        """Internal logging method"""
        if self.output_callback:
            self.output_callback(message, message_type)
        else:
            print(message)
    
    def fetch_headlines(self, max_headlines_per_source: int = 5) -> List[Dict]:
        """Fetch headlines with SSL fix"""
        all_headlines = []
        successful_sources = 0
        
        self._log("Fetching headlines from tech & business sources...")
        self._log("=" * 50)
        
        for i, source in enumerate(self.news_sources, 1):
            try:
                self._log(f"{i}/{len(self.news_sources)} 📰 {source.name}")
                
                # Parse feed with SSL fix
                feed = feedparser.parse(source.url)
                
                if not hasattr(feed, 'entries') or len(feed.entries) == 0:
                    self._log(f"    ❌ No entries found in {source.name}")
                    continue
                
                source_count = 0
                for entry in feed.entries[:max_headlines_per_source * 2]:
                    try:
                        title = getattr(entry, 'title', '').strip()
                        if not title:
                            continue
                            
                        headline = {
                            'title': title,
                            'source': source.name,
                            'category': source.category,
                            'url': getattr(entry, 'link', ''),
                            'published': getattr(entry, 'published', ''),
                            'summary': getattr(entry, 'summary', '')[:300] if hasattr(entry, 'summary') and entry.summary else ''
                        }
                        
                        # Simple relevance check
                        if self._is_tech_business_relevant(headline):
                            all_headlines.append(headline)
                            source_count += 1
                            
                            if source_count <= 2:
                                self._log(f"    ✅ '{title[:50]}{'...' if len(title) > 50 else ''}'")
                            
                            if source_count >= max_headlines_per_source:
                                break
                                
                    except Exception as e:
                        continue
                
                if source_count > 0:
                    successful_sources += 1
                    self._log(f"    ✅ Collected {source_count} headlines")
                else:
                    self._log(f"    ❌ No relevant headlines from {source.name}")
                
                time.sleep(0.5)
                
            except Exception as e:
                self._log(f"    ❌ Error fetching from {source.name}: {e}", "error")
                continue
        
        self._log(f"\n📊 Collection Summary:")
        self._log(f"   • Total headlines: {len(all_headlines)}")
        self._log(f"   • Successful sources: {successful_sources}/{len(self.news_sources)}")
        
        return all_headlines
    
    def _is_tech_business_relevant(self, headline: Dict) -> bool:
        """Check if headline is tech/business relevant"""
        title = headline['title'].lower()
        summary = headline.get('summary', '').lower()
        combined_text = f"{title} {summary}"
        
        # Always include tech/business categories
        if headline['category'] in ['technology', 'business']:
            return True
        
        # For world news, check keywords
        if headline['category'] == 'world':
            return any(keyword in combined_text for keyword in self.tech_business_keywords)
        
        return True
    
    def analyze_headlines(self, headlines: List[Dict]) -> Dict:
        """Analyze headlines with LLM"""
        if not headlines:
            return {
                "summary": "No headlines available for analysis",
                "keywords": ["technology", "business", "innovation"],
                "trending_topics": ["Technology trends"],
                "search_keywords": ["technology", "business", "innovation"],
                "analysis_timestamp": datetime.now().isoformat()
            }
        
        # Simple single-batch analysis for quick results
        headlines_text = ""
        for headline in headlines[:20]:  # Limit to 20 for speed
            headlines_text += f"• {headline['title']} ({headline['source']})\n"

        prompt = f"""Analyze these tech and business headlines. Extract ONLY single-word keywords (no phrases).

Headlines:
{headlines_text}

Respond in JSON format:
{{
    "summary": "2-3 sentence summary of key tech/business trends",
    "keywords": ["word1", "word2", "word3"],
    "trending_topics": ["topic1", "topic2"]
}}

Keywords must be single words only."""

        try:
            self._log("🧠 Analyzing headlines with AI...")
            
            response = ollama.chat(model=self.ollama_model, messages=[
                {'role': 'user', 'content': prompt}
            ])

            response_text = response['message']['content'].strip()
            
            # Extract JSON
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                analysis = json.loads(json_match.group())
                
                # Ensure single-word keywords
                if 'keywords' in analysis:
                    single_words = []
                    for kw in analysis['keywords']:
                        clean_kw = kw.strip().lower()
                        if ' ' not in clean_kw and 2 <= len(clean_kw) <= 20:
                            single_words.append(clean_kw)
                    analysis['keywords'] = single_words
                
                analysis['search_keywords'] = analysis.get('keywords', [])
                analysis['analysis_timestamp'] = datetime.now().isoformat()
                
                return analysis
            
        except Exception as e:
            self._log(f"❌ AI analysis failed: {e}", "error")
        
        # Fallback analysis
        return {
            "summary": f"Analyzed {len(headlines)} headlines covering technology and business topics",
            "keywords": ["technology", "business", "innovation", "market", "startup"],
            "trending_topics": ["Technology developments", "Business trends"],
            "search_keywords": ["technology", "business", "innovation", "market", "startup"],
            "analysis_timestamp": datetime.now().isoformat()
        }
    
    def save_analysis(self, headlines: List[Dict], analysis: Dict, filename: Optional[str] = None):
        """Save analysis to file"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d")
            filename = f"current_events_analysis_{timestamp}.json"

        full_path = os.path.join(self.data_directory, filename)
        
        output = {
            "analysis": analysis,
            "focus": "technology_and_business",
            "headline_count": len(headlines),
            "sources_analyzed": list(set([h['source'] for h in headlines])),
            "raw_headlines": headlines
        }

        with open(full_path, 'w', encoding='utf-8') as f:
            json.dump(output, f, indent=2, ensure_ascii=False)
        
        self._log(f"💾 Analysis saved to: {full_path}")
        return filename
    
    def check_existing_analysis(self) -> Optional[str]:
        """Check for existing analysis from today"""
        today = datetime.now().strftime("%Y%m%d")
        pattern = os.path.join(self.data_directory, f"current_events_analysis_{today}.json")
        files = glob.glob(pattern)
        return max(files, key=os.path.getctime) if files else None
    
    def load_existing_analysis(self, filename: str) -> Dict:
        """Load existing analysis"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            analysis = data.get('analysis', {})
            
            self._log("📂 Found existing analysis from today!")
            self._log(f"📁 File: {filename}")
            self._log(f"📊 Headlines: {data.get('headline_count', 0)}")
            
            keywords = analysis.get('search_keywords', [])
            if keywords:
                self._log(f"🔍 Keywords: {', '.join(keywords[:10])}")
            
            return analysis
            
        except Exception as e:
            self._log(f"❌ Error loading analysis: {e}", "error")
            return {}
    
    def run_analysis(self, max_headlines_per_source: int = 5, save_results: bool = True, force: bool = False, db_path: str = None) -> Dict:
        """Run complete analysis pipeline"""
        # Check existing unless forced
        if not force:
            existing_file = self.check_existing_analysis()
            if existing_file:
                return self.load_existing_analysis(existing_file)

        # Clear hot topics flags if first run
        if db_path and not self.check_existing_analysis():
            self._log("🧹 Clearing previous hot topics flags...")
            self.clear_hot_topics_flags(db_path)

        self._log("🚀 Starting Tech & Business Analysis")
        self._log("=" * 40)
        
        # Fetch headlines
        headlines = self.fetch_headlines(max_headlines_per_source)
        
        if not headlines:
            self._log("⚠️ No headlines collected - using fallback", "warning")
            # Create minimal fallback
            fallback_analysis = {
                "summary": "Unable to collect headlines due to connectivity issues",
                "keywords": ["technology", "business", "market", "innovation"],
                "trending_topics": ["Technology trends", "Business developments"],
                "search_keywords": ["technology", "business", "market", "innovation"],
                "analysis_timestamp": datetime.now().isoformat(),
                "fallback": True
            }
            
            if save_results:
                self.save_analysis([], fallback_analysis)
            
            return fallback_analysis
        
        # Analyze headlines
        analysis = self.analyze_headlines(headlines)
        
        # Save results
        if save_results:
            filename = self.save_analysis(headlines, analysis)
            analysis['saved_file'] = filename
        
        # Display results
        self._log(f"\n✅ Analysis Complete!")
        self._log(f"📊 Headlines: {len(headlines)}")
        self._log(f"🔍 Keywords: {len(analysis.get('search_keywords', []))}")
        
        keywords = analysis.get('search_keywords', [])
        if keywords:
            self._log(f"💡 Top keywords: {', '.join(keywords[:5])}")
        
        return analysis

    def clear_hot_topics_flags(self, db_path: str):
        """Clear hot topics flags from database"""
        try:
            with self.get_db_connection(db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE content 
                    SET relevance_boost = 0, hot_topics_date = NULL, hot_topics_keywords_used = NULL
                ''')
                rows_updated = cursor.rowcount
                conn.commit()
                self._log(f"🧹 Cleared flags from {rows_updated} articles")
                return rows_updated
        except Exception as e:
            self._log(f"❌ Error clearing flags: {e}", "error")
            return 0


def main():
    """Main function for standalone testing"""
    print("SSL-Fixed Current Events Analyzer")
    print("-" * 40)
    
    analyzer = TechBusinessEventsAnalyzer()
    
    try:
        results = analyzer.run_analysis(force=True)
        
        if results:
            keywords = results.get('search_keywords', [])
            print(f"\n✅ Generated {len(keywords)} keywords")
            if keywords:
                print(f"💡 Keywords: {', '.join(keywords[:8])}")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")


if __name__ == "__main__":
    main()