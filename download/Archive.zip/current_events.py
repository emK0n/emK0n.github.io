#!/usr/bin/env python3
"""
Current Events Flask Routes
Handles web interface for current events analysis
FIXED: Enhanced error handling and debugging for null analysis errors
"""
import json
import time
import os
import threading
from datetime import datetime
from flask import Blueprint, jsonify
from current_events_analyzer import TechBusinessEventsAnalyzer

# Create blueprint
current_events_bp = Blueprint('current_events', __name__)

# Global variables for tracking analysis progress
current_events_output = []
current_events_progress = 0
current_events_status = "idle"
current_events_completed = False
current_events_success = False
current_events_error = None
current_events_thread = None
analyzer_instance = None
DATA_DIRECTORY = "data"  # Default fallback

def set_data_directory(data_dir: str):
    global DATA_DIRECTORY
    DATA_DIRECTORY = data_dir

def _run_analysis_logic():
    """Shared analysis logic for both routes and podcast - FIXED with enhanced error handling"""
    global current_events_completed, current_events_success, current_events_error
    global analyzer_instance

    try:
        add_output("🚀 Initializing Current Events Analyzer...")
        update_progress(5, "Initializing...")

        # Create analyzer with output callback and enhanced error handling
        try:
            analyzer_instance = TechBusinessEventsAnalyzer(
                output_callback=analyze_output_callback,
                data_directory=DATA_DIRECTORY
            )
            add_output("✅ Analyzer initialized successfully")
        except Exception as e:
            error_msg = f"Failed to initialize analyzer: {str(e)}"
            add_output(f"❌ {error_msg}", "error")
            current_events_error = error_msg
            current_events_success = False
            current_events_completed = True
            return

        add_output("📡 Starting tech & business news analysis...")
        update_progress(10, "Starting analysis...")

        # Check if Ollama is available
        try:
            import ollama
            # Test connection with a simple query
            test_response = ollama.chat(
                model=analyzer_instance.ollama_model, 
                messages=[{'role': 'user', 'content': 'test'}]
            )
            add_output("✅ Ollama connection verified")
        except Exception as e:
            error_msg = f"Ollama connection failed: {str(e)}. Make sure Ollama is running with model '{analyzer_instance.ollama_model}'"
            add_output(f"❌ {error_msg}", "error")
            current_events_error = error_msg
            current_events_success = False
            current_events_completed = True
            return

        # Run the analysis with detailed error handling
        try:
            add_output("🔍 Running complete analysis pipeline...")
            results = analyzer_instance.run_analysis(
                max_headlines_per_source=3,
                save_results=True,
                force=False,
                db_path=os.path.join(DATA_DIRECTORY, "content_curator.db")
            )
            add_output(f"📊 Analysis pipeline completed, checking results...")
            
        except Exception as e:
            error_msg = f"Analysis pipeline failed: {str(e)}"
            add_output(f"❌ {error_msg}", "error")
            current_events_error = error_msg
            current_events_success = False
            current_events_completed = True
            return

        # Validate results
        if not results:
            error_msg = "Analysis completed but returned empty results"
            add_output(f"❌ {error_msg}", "error")
            current_events_error = error_msg
            current_events_success = False
            current_events_completed = True
            return

        if not isinstance(results, dict):
            error_msg = f"Analysis returned invalid data type: {type(results)}"
            add_output(f"❌ {error_msg}", "error")
            current_events_error = error_msg
            current_events_success = False
            current_events_completed = True
            return

        # Check for required keys in results
        required_keys = ['search_keywords', 'trending_topics']
        missing_keys = [key for key in required_keys if key not in results]
        if missing_keys:
            error_msg = f"Analysis results missing required keys: {missing_keys}"
            add_output(f"❌ {error_msg}", "error")
            current_events_error = error_msg
            current_events_success = False
            current_events_completed = True
            return

        # Extract and validate data
        keywords = results.get('search_keywords', [])
        topics = results.get('trending_topics', [])

        if not keywords and not topics:
            error_msg = "Analysis completed but generated no keywords or topics"
            add_output(f"⚠️ {error_msg}", "warning")

        add_output(f"✅ Analysis completed successfully!")
        add_output(f"📊 Generated {len(keywords)} single-word keywords")
        add_output(f"🔥 Identified {len(topics)} trending topics")

        if keywords:
            add_output(f"💡 Top keywords: {', '.join(keywords[:5])}")

        update_progress(100, "Analysis complete!")
        current_events_success = True

    except Exception as e:
        import traceback
        error_msg = f"Unexpected error during analysis: {str(e)}"
        add_output(f"❌ {error_msg}", "error")
        add_output(f"🔍 Full traceback: {traceback.format_exc()}", "error")
        current_events_error = error_msg
        current_events_success = False
        update_progress(0, "Error occurred")

    finally:
        current_events_completed = True
        analyzer_instance = None
        add_output(f"🏁 Analysis process completed. Success: {current_events_success}")

def _reset_and_start_analysis():
    """Reset tracking variables and start analysis thread"""
    global current_events_output, current_events_progress, current_events_status
    global current_events_completed, current_events_success, current_events_error
    global current_events_thread

    # Reset tracking variables
    current_events_output = []
    current_events_progress = 0
    current_events_status = "Starting analysis..."
    current_events_completed = False
    current_events_success = False
    current_events_error = None

    # Start the thread
    current_events_thread = threading.Thread(target=_run_analysis_logic, daemon=True)
    current_events_thread.start()

def add_output(message: str, message_type: str = "info"):
    """Add a message to the output log"""
    global current_events_output
    timestamp = datetime.now().isoformat()
    current_events_output.append({
        'message': message,
        'type': message_type,
        'timestamp': time.time()
    })
    
    # Also print to console for debugging
    print(f"[{timestamp}] {message_type.upper()}: {message}")

def update_progress(progress: int, status: str):
    """Update the progress and status"""
    global current_events_progress, current_events_status
    current_events_progress = progress
    current_events_status = status
    print(f"Progress: {progress}% - {status}")

@current_events_bp.route('/api/run-current-events', methods=['POST'])
def run_current_events():
    try:
        print("🚀 Starting current events analysis from API endpoint...")
        _reset_and_start_analysis()
        return jsonify({"status": "started"})
    except Exception as e:
        error_msg = f"Failed to start current events analysis: {str(e)}"
        print(f"❌ {error_msg}")
        return jsonify({"status": "error", "message": error_msg}), 500

def trigger_analysis_for_podcast():
    """Trigger analysis specifically for podcast workflow"""
    print("🎙️ Triggering current events analysis for podcast...")
    _reset_and_start_analysis()

def analyze_output_callback(message: str, message_type: str = "info"):
    """Callback function to handle output from the analyzer"""
    global current_events_progress, current_events_status

    # Add the message to output
    add_output(message, message_type)

    # Update progress based on message content
    message_lower = message.lower()

    if 'starting ai analysis - sending first batch' in message_lower:
        update_progress(40, "AI analyzing first batch...")
    elif 'complete - sending batch' in message_lower:
        # Extract batch number for better progress
        if 'batch 2/' in message_lower:
            update_progress(60, "AI analyzing batch 2...")
        elif 'batch 3/' in message_lower:
            update_progress(80, "AI analyzing batch 3...")
        else:
            update_progress(70, "AI analyzing next batch...")
    elif 'analysis complete' in message_lower and 'batch' in message_lower:
        update_progress(85, "Batch analysis complete...")

    # EXISTING PATTERNS (keep these):
    if 'fetching headlines' in message_lower:
        update_progress(15, "Fetching headlines...")
    elif 'collected' in message_lower and 'headlines' in message_lower:
        update_progress(25, "Headlines collected")
    elif 'analyzing' in message_lower and 'headlines' in message_lower:
        update_progress(35, "Starting AI analysis...")
    elif 'consolidating' in message_lower:
        update_progress(90, "Consolidating results...")
    elif 'analysis saved' in message_lower:
        update_progress(95, "Saving results...")
    elif 'analysis complete' in message_lower and 'tech/business' in message_lower:
        update_progress(100, "Analysis complete!")

def get_current_events_status():
    """Get current status for external monitoring"""
    return {
        'completed': current_events_completed,
        'success': current_events_success,
        'error': current_events_error,
        'status': current_events_status,
        'progress': current_events_progress
    }

@current_events_bp.route('/api/current-events-status', methods=['GET'])
def current_events_status_route():
    global current_events_output, current_events_progress, current_events_status
    global current_events_completed, current_events_success, current_events_error

    # Return recent output (last 10 messages to avoid overwhelming)
    recent_output = current_events_output[-10:] if len(current_events_output) > 0 else []

    # Base response with your existing data
    response = {
        "progress": current_events_progress,
        "status": current_events_status,
        "new_output": recent_output,
        "total_output_lines": len(current_events_output),
        "completed": current_events_completed,
        "success": current_events_success if current_events_completed else None,
        "error": current_events_error,
        "timestamp": time.time()
    }

    # Add batch processing info from curator's progress tracker
    try:
        from app import curator
        curator_progress = curator.get_operation_progress()

        if curator_progress and curator_progress.get('batch_processing'):
            response.update({
                'batch_processing': True,
                'current_batch': curator_progress.get('current_batch', 0),
                'total_batches': curator_progress.get('total_batches', 0),
                'batch_progress_percent': curator_progress.get('batch_progress_percent', 0),
                'current_message': curator_progress.get('current_message', '')
            })
        else:
            response['batch_processing'] = False

    except Exception as e:
        # If there's any error accessing curator progress, just continue with existing data
        print(f"Warning: Could not access curator progress: {e}")
        response['batch_processing'] = False

    return jsonify(response)

@current_events_bp.route('/api/current-events-results', methods=['GET'])
def get_current_events_results():
    """Get the latest analysis results"""
    try:
        # Try to find the most recent analysis file
        analyzer = TechBusinessEventsAnalyzer(data_directory=DATA_DIRECTORY)
        existing_file = analyzer.check_existing_analysis()
        
        if existing_file:
            with open(existing_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            return jsonify({
                "status": "success",
                "data": data,
                "file": existing_file,
                "timestamp": datetime.fromtimestamp(time.time()).isoformat()
            })
        else:
            return jsonify({
                "status": "no_data",
                "message": "No current events analysis found for today"
            })
            
    except Exception as e:
        return jsonify({
            "status": "error", 
            "message": str(e)
        })

# Health check endpoint
@current_events_bp.route('/api/current-events-health', methods=['GET'])
def health_check():
    """Simple health check for the current events service"""
    try:
        # Test basic functionality
        analyzer = TechBusinessEventsAnalyzer(data_directory=DATA_DIRECTORY)
        
        # Test Ollama connection
        import ollama
        test_response = ollama.chat(
            model=analyzer.ollama_model, 
            messages=[{'role': 'user', 'content': 'health check'}]
        )
        
        return jsonify({
            "status": "healthy",
            "service": "current_events_analyzer",
            "ollama_model": analyzer.ollama_model,
            "data_directory": DATA_DIRECTORY,
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "status": "unhealthy",
            "service": "current_events_analyzer", 
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }), 500
