"""
Enhanced Research Assistant Agent with Internet Search Capabilities
Adds search functionality while preserving existing workflow
"""

import sqlite3
import json
import time
import threading
import ollama
import glob
import os
import re
from typing import List, Dict, Optional, Any, Tuple
from contextlib import contextmanager
import hashlib
from datetime import datetime, timedelta

DATA_DIRECTORY = "data"

try:
    from pdf_parser import is_pdf_url, process_pdf
    HAS_PDF_SUPPORT = True
except ImportError:
    HAS_PDF_SUPPORT = False


class ResearchAgentSession:
    """Manages a single research session with state tracking"""
    
    def __init__(self, session_id: str, db_path: str):
        self.session_id = session_id
        self.db_path = db_path
        self.state = "initialization"  # initialization -> hot_topics -> interests -> collection -> presentation -> chat -> search
        self.context = {}
        self.created_at = datetime.now()
        self.chain_config = {
            'enabled': False,
            'steps': [],  # ['collection', 'week_review', 'podcast']
            'current_step': None,
            'completed_steps': [],
            'step_data': {}  # Store results from each step
        }
        
    def update_state(self, new_state: str, context_update: Dict = None):
        """Update workflow state and context"""
        self.state = new_state
        if context_update:
            self.context.update(context_update)
        print(f"🔄 Agent state: {self.state}")


    def enable_chain_workflow(self, steps: List[str]):
        """Enable chain workflow with specified steps"""
        self.chain_config['enabled'] = True
        self.chain_config['steps'] = steps
        self.chain_config['current_step'] = steps[0] if steps else None


    def advance_chain_step(self):
        """Move to next step in chain"""
        if not self.chain_config['enabled']:
            return None

        current = self.chain_config['current_step']
        if current and current not in self.chain_config['completed_steps']:
            self.chain_config['completed_steps'].append(current)

        remaining_steps = [s for s in self.chain_config['steps']
                           if s not in self.chain_config['completed_steps']]

        self.chain_config['current_step'] = remaining_steps[0] if remaining_steps else None
        return self.chain_config['current_step']


    def is_chain_complete(self) -> bool:
        """Check if all chain steps are complete"""
        return (self.chain_config['enabled'] and
                len(self.chain_config['completed_steps']) == len(self.chain_config['steps']))


    def store_chain_step_data(self, step: str, data: dict):
        """Store data from completed chain step"""
        self.chain_config['step_data'][step] = data


class ResearchAssistant:
    """Enhanced Research Assistant with Internet Search"""
    
    def __init__(self, content_curator, chat_assistant):
        self.content_curator = content_curator
        self.chat_assistant = chat_assistant
        self.ollama_model = content_curator.ollama_model
        self.sessions = {}

    def _is_interests_command(self, message: str) -> bool:
        message_lower = message.lower().strip()

        # Exclude research workflow phrases first
        exclusions = [
            "what's going on", "whats going on", "going on", "current events",
            "hot topics", "analyze today", "today's analysis"
        ]
        if any(exclusion in message_lower for exclusion in exclusions):
            return False

        # Expanded interests patterns
        interests_patterns = [
            # Show/List variations
            'show my interests', 'list my interests', 'my interests',
            'show interests', 'list interests', 'view interests',
            'interest list', 'show interest list', 'list interest',
            'what are my interests', 'display interests',

            # Add variations
            'add interest', 'add an interest', 'new interest',
            'add topic', 'create interest',

            # Remove variations
            'remove interest', 'delete interest', 'remove an interest',
            'delete topic', 'drop interest',

            # Weight variations
            'change weight', 'set weight', 'update weight', 'modify weight',
            'weight of', 'interest weight', 'adjust weight',

            # Help
            'interests help', 'help with interests'
        ]

        # Also check if message contains "interest" + action words
        if 'interest' in message_lower:
            action_words = ['show', 'list', 'add', 'remove', 'delete', 'change', 'set', 'update', 'weight']
            if any(word in message_lower for word in action_words):
                return True

        return any(pattern in message_lower for pattern in interests_patterns)


    def _handle_system_message(self, session: ResearchAgentSession, message: str) -> Dict:
        """Handle system messages that auto-advance the workflow"""
        if message == 'hot_topics_complete':
            return self._auto_advance_from_hot_topics(session)
        elif message == 'collection_complete':
            if session.chain_config['enabled'] and session.chain_config['current_step'] == 'collection':
                return self._handle_chain_step_completion(session, 'collection')
            else:
                # Original behavior for non-chain workflows
                return self._auto_advance_from_collection(session)
                # NEW: Chain-specific completion handlers
        elif message == 'week_review_complete':
            if session.chain_config['enabled'] and session.chain_config['current_step'] == 'week_review':
                return self._handle_chain_step_completion(session, 'week_review')
            else:
                return {'response': 'Week review completed', 'state': session.state}
        elif message == 'podcast_complete':
            if session.chain_config['enabled'] and session.chain_config['current_step'] == 'podcast':
                return self._handle_chain_step_completion(session, 'podcast')
            else:
                return {'response': 'Podcast generation completed', 'state': session.state}
        elif message == 'SYSTEM_TRIGGER_RESEARCH_WORKFLOW':
            # Special trigger from frontend button - go directly to research workflow
            print("🎯 Frontend button triggered research workflow")
            return self._check_hot_topics(session)
        else:
            if session.state in ['interests', 'hot_topics_generating']:
                return self._auto_advance_from_hot_topics(session)
            else:
                return {'response': 'System message received', 'state': session.state}

    def _check_hot_topics(self, session: ResearchAgentSession) -> Dict:
        """Enhanced hot topics checking with smart boost status detection"""
        # Check if force refresh was requested
        force_refresh = session.context.get('force_refresh', False)

        if force_refresh:
            print("🔄 Force refresh requested - skipping all boost checks and proceeding to collection")
            self._mark_morning_greeting_shown()
            # Go directly to collection workflow as if no hot topics exist
            return self._check_hot_topics_files(session, skip_existing=True)

        today_date = datetime.now().strftime('%Y-%m-%d')

        # Step 1: Check if we already have boost scoring for today
        boost_status = self.content_curator.check_hot_topics_boost_status(today_date)
        session.context['boost_check_performed'] = True
        session.context['existing_boost_status'] = boost_status

        print(f"🔍 Checking hot topics boost status for {today_date}")
        print(f"   Boost scoring exists: {boost_status['has_boost_scoring']}")
        print(f"   Boosted articles: {boost_status['boosted_articles_count']}")
        print(f"   Quality threshold met: {boost_status['quality_threshold_met']}")

        # Step 2: Decide workflow path based on boost status
        if boost_status['quality_threshold_met']:
            # Good boost data exists - skip to results
            print("✅ Quality boost data found, showing existing results...")
            self._mark_morning_greeting_shown()
            session.update_state("presentation", {
                "skip_collection_reason": "existing_quality_boost_data",
                "boost_status": boost_status
            })
            return self._prepare_existing_results_for_modal(session)

        elif boost_status['has_boost_scoring']:
            # Some boost data exists but not enough - offer refresh option
            print("⚠️ Some boost data found but below quality threshold, offering refresh...")
            self._mark_morning_greeting_shown()
            session.update_state("refresh_option", {
                "boost_status": boost_status
            })
            return self._add_refresh_collection_option(session, boost_status)

        else:
            # No boost data - check for hot topics files and generate if needed
            print("🔍 No boost data found, checking for hot topics files...")
            return self._check_hot_topics_files(session, skip_existing=False)

    def _check_hot_topics_files(self, session: ResearchAgentSession, skip_existing: bool = False) -> Dict:
        """Check for existing hot topics files or generate new analysis"""
        if skip_existing:
            print("🔄 Skipping existing hot topics files check - generating fresh analysis")
            session.update_state("hot_topics_generating")
            return {
                'response': "🔄 **Generating Fresh Hot Topics Analysis**\n\nIgnoring existing data and analyzing current events from scratch...",
                'actions': [{'type': 'generate_hot_topics'}],
                'state': 'hot_topics_generating',
                'show_progress': True
            }

        # Check for existing hot topics files
        today = datetime.now().strftime("%Y%m%d")
        hot_topics_files = glob.glob(os.path.join(DATA_DIRECTORY, f"current_events_analysis_{today}.json"))

        if hot_topics_files:
            # Found existing hot topics files - load and use them
            print(f"✅ Found {len(hot_topics_files)} hot topics files for today")
            try:
                latest_file = max(hot_topics_files, key=os.path.getctime)
                with open(latest_file, 'r', encoding='utf-8') as f:
                    hot_topics_data = json.load(f)

                keywords = hot_topics_data.get('analysis', {}).get('search_keywords', [])
                if keywords:
                    session.context['hot_topics_keywords'] = keywords
                    print(f"✅ Loaded {len(keywords)} hot topics keywords from existing file")
                    self._mark_morning_greeting_shown()
                    # Proceed to interests/collection
                    return self._auto_advance_from_hot_topics(session)
                else:
                    print("⚠️ Hot topics file exists but no keywords found - generating new analysis")

            except Exception as e:
                print(f"❌ Error loading hot topics file: {e}")

        # No usable hot topics files found - generate new analysis
        print("🔍 No usable hot topics files found, generating new analysis...")
        session.update_state("hot_topics_generating")
        return {
            'response': "🔍 **Analyzing Current Events**\n\nGenerating today's hot topics analysis...",
            'actions': [{'type': 'generate_hot_topics'}],
            'state': 'hot_topics_generating',
            'show_progress': True
        }

    def _show_existing_results(self, session: ResearchAgentSession) -> Dict:
        """Display results immediately when quality hot topics boost data exists"""
        try:
            boost_status = session.context.get('existing_boost_status', {})

            # Load top articles with existing boost scores
            top_articles = self._get_top_articles(session)

            if not top_articles:
                return {
                    'response': "📭 **No boosted articles found**\n\nEven though boost scoring exists, no articles were found. This might mean:\n• Articles are older than our search timeframe\n• Boost scores didn't meet minimum thresholds\n\nWould you like to run a fresh collection?",
                    'actions': [{'type': 'show_refresh_option'}],
                    'state': 'refresh_option'
                }

            # Generate summary with boost information
            keywords_used = boost_status.get('keywords_used', [])
            keywords_text = ', '.join(keywords_used[:5]) if keywords_used else 'various topics'

            summary = f"""🎯 **Today's Research Results Ready!**

    📊 **Existing Analysis Status:**
    - {boost_status['boosted_articles_count']} articles boosted with hot topics
    - Average boost: +{boost_status['average_boost']:.1f} points
    - Keywords used: {keywords_text}
    - Quality threshold: ✅ Met

    🏆 **Top Finding:** {top_articles[0]['title'][:60]}...
       Total Relevance: {top_articles[0].get('total_relevance', 0):.1f}/10

    💬 **Available Commands:**
    - Discuss any article by clicking "Discuss"
    - Ask me to "search for [topic]" to find current info
    - Say "refresh collection" for new data

    📋 **Your Boosted Research Articles**
    These articles have been enhanced with today's hot topics scoring:"""

            session.update_state("chat", {
                "top_articles": top_articles,
                "used_existing_boost": True,
                "boost_status": boost_status
            })

            return {
                'response': summary,
                'actions': [{'type': 'show_articles_table', 'articles': top_articles}],
                'state': 'chat',
                'show_table': True,
                'boost_info': boost_status
            }

        except Exception as e:
            print(f"Error showing existing results: {e}")
            # Fallback to refresh option
            session.update_state("refresh_option")
            return {
                'response': f"❌ **Error loading existing results**\n\n{str(e)}\n\nWould you like to run a fresh collection instead?",
                'actions': [{'type': 'show_refresh_option'}],
                'state': 'refresh_option'
            }

    def _add_refresh_collection_option(self, session: ResearchAgentSession, boost_status: Dict) -> Dict:
        """Provide option to refresh collection when some boost data exists"""
        try:
            keywords_used = boost_status.get('keywords_used', [])
            keywords_text = ', '.join(keywords_used[:3]) if keywords_used else 'previous keywords'

            response = f"""⚠️ **Partial Hot Topics Data Found**

    📊 **Current Status:**
    - {boost_status['boosted_articles_count']} articles have boost scoring
    - Keywords from earlier: {keywords_text}
    - Quality threshold: ❌ Not quite met

    🤔 **What would you like to do?**

    **Option 1:** Show current results anyway
    - See what we have with existing boost scores
    - Faster, but may have fewer relevant articles

    **Option 2:** Refresh collection (recommended)
    - Generate fresh hot topics analysis
    - Collect and boost new articles
    - Takes a few minutes but gives better results

    Just tell me "show current results" or "refresh collection" to proceed."""

            session.context['refresh_option_shown'] = True

            return {
                'response': response,
                'actions': [],
                'state': 'refresh_option',
                'boost_status': boost_status
            }

        except Exception as e:
            print(f"Error creating refresh option: {e}")
            # Fallback to auto-advance
            return self._auto_advance_from_hot_topics(session)

    def _handle_refresh_option_response(self, session: ResearchAgentSession, message: str) -> Dict:
        """Handle user choice between showing current results or refreshing collection"""
        message_lower = message.lower().strip()

        if any(phrase in message_lower for phrase in ['show current', 'current results', 'show existing', 'show what']):
            # User wants to see current results with existing boost
            print("👀 User chose to show current results with existing boost")
            session.update_state("presentation", {
                "skip_collection_reason": "user_chose_existing_boost"
            })
            return self._show_existing_results(session)

        elif any(phrase in message_lower for phrase in ['refresh', 'new collection', 'fresh', 'update']):
            # User wants fresh collection
            print("🔄 User chose to refresh collection")
            session.update_state("interests", {
                "force_refresh": True,
                "skip_existing_boost": True
            })
            return self._auto_advance_from_hot_topics(session,
                                                      hot_topics_message="🔄 **Starting Fresh Collection**\n\nIgnoring existing boost data and generating new hot topics analysis...\n\n")
        else:
            # Unclear response, ask again
            return {
                'response': "🤔 **Please clarify your choice:**\n\n• Say \"show current results\" to see existing articles\n• Say \"refresh collection\" to gather fresh data\n\nWhich would you prefer?",
                'actions': [],
                'state': 'refresh_option'
            }


    def _prepare_existing_results_for_modal(self, session: ResearchAgentSession) -> Dict:
        """Prepare existing results to be displayed in modal instead of workflow"""
        try:
            boost_status = session.context.get('existing_boost_status', {})

            # Load top articles with existing boost scores
            top_articles = self._get_top_articles(session)

            if not top_articles:
                return {
                    'response': "📭 **No boosted articles found**\n\nEven though boost scoring exists, no articles were found. This might mean:\n• Articles are older than our search timeframe\n• Boost scores didn't meet minimum thresholds\n\nWould you like to run a fresh collection?",
                    'actions': [{'type': 'show_refresh_option'}],
                    'state': 'refresh_option'
                }

            # Generate summary with boost information
            keywords_used = boost_status.get('keywords_used', [])
            keywords_text = ', '.join(keywords_used[:5]) if keywords_used else 'various topics'

            summary = f"""🎯 **Today's Research Results Ready!**

    📊 **Existing Analysis Status:**
    - {boost_status['boosted_articles_count']} articles boosted with hot topics
    - Average boost: +{boost_status['average_boost']:.1f} points
    - Keywords used: {keywords_text}
    - Quality threshold: ✅ Met

    🏆 **Top Finding:** {top_articles[0]['title'][:60]}...
       Total Relevance: {top_articles[0].get('total_relevance', 0):.1f}/10

    📋 **Opening research results modal with {len(top_articles)} articles...**

    💬 **Available Commands:**
    - Discuss any article by clicking "Discuss"
    - Ask me to "search for [topic]" to find current info
    - Say "refresh collection" for new data"""

            session.update_state("chat", {
                "top_articles": top_articles,
                "used_existing_boost": True,
                "boost_status": boost_status
            })

            # NEW: Return action to show articles in modal
            return {
                'response': summary,
                'actions': [{'type': 'show_existing_results_modal', 'articles': top_articles}],
                'state': 'chat',
                'show_modal': True,
                'boost_info': boost_status
            }

        except Exception as e:
            print(f"Error preparing existing results: {e}")
            # Fallback to refresh option
            session.update_state("refresh_option")
            return {
                'response': f"❌ **Error loading existing results**\n\n{str(e)}\n\nWould you like to run a fresh collection instead?",
                'actions': [{'type': 'show_refresh_option'}],
                'state': 'refresh_option'
            }

    def _show_existing_results(self, session: ResearchAgentSession) -> Dict:
        """Display results immediately when quality hot topics boost data exists - DEPRECATED"""
        # This method is now replaced by _prepare_existing_results_for_modal
        # Keep for backward compatibility but redirect to new method
        print("⚠️ _show_existing_results called - redirecting to modal preparation")
        return self._prepare_existing_results_for_modal(session)

    # NEW: Add this method to app.py to handle the existing results modal action
    # Add this to the handleActions function in app.py:

    def _auto_advance_from_hot_topics(self, session: ResearchAgentSession, hot_topics_message: str = None) -> Dict:
        """Automatically advance from hot topics completion to collection start"""
        try:
            self._mark_morning_greeting_shown()
            # Load user interests
            conn = sqlite3.connect(self.content_curator.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT interest, weight FROM user_interests ORDER BY weight DESC')
            interests = [dict(row) for row in cursor.fetchall()]
            conn.close()

            # Use default timeframe and start collection immediately
            default_hours = 48
            session.update_state("collection", {
                "interests": interests,
                "timeframe_hours": default_hours
            })

            # Format interests display
            if interests:
                interests_list = ", ".join([f"{i['interest']} ({i['weight']:.1f})" for i in interests])
                interests_text = f"📋 **Your Research Interests:** {interests_list}"
            else:
                interests_text = "📋 **No specific interests configured** - using general scoring"

            hot_topics_count = len(session.context.get("hot_topics_keywords", []))

            # Use provided hot topics message or default
            hot_topics_part = hot_topics_message or "✅ **Hot Topics Analysis Complete**"
            hot_topics_keywords = session.context.get("hot_topics_keywords", [])


            return {
                'response': f"{hot_topics_part}\n\n{interests_text}\n\n🚀 **Starting Research Collection**\n\n📊 **Parameters:**\n• Timeframe: 48 hours (default)\n• Research interests: {len(interests)} configured\n• Hot topics boost: {hot_topics_count} keywords\n\nGathering articles from all sources...",
                'actions': [{'type': 'start_collection', 'timeframe_hours': default_hours, 'max_process': None, 'hot_topics_keywords': hot_topics_keywords}],
                'state': 'collection',
                'show_progress': True,
                'auto_advance': True
            }

        except Exception as e:
            # Fallback to safe defaults
            self._mark_morning_greeting_shown()
            session.update_state("collection", {"timeframe_hours": 48, "interests": []})
            return {
                'response': f"✅ **Hot Topics Ready** (with fallback settings)\n\n🚀 **Starting Research Collection**\n\nUsing 48-hour timeframe and general scoring...",
                'actions': [{'type': 'start_collection', 'timeframe_hours': 48}],
                'state': 'collection',
                'show_progress': True,
                'auto_advance': True
            }

    def start_session(self, session_id: str, auto_start_workflow: bool = False, chain_workflow: bool = False,
                      skip_morning_greeting: bool = False, force_refresh: bool = False) -> Dict:
        """Start a new research session"""

        print(f"🔍 DEBUG start_session called with:")
        print(f"   session_id: {session_id}")
        print(f"   auto_start_workflow: {auto_start_workflow}")
        print(f"   chain_workflow: {chain_workflow}")
        print(f"   skip_morning_greeting: {skip_morning_greeting}")
        print(f"   force_refresh: {force_refresh}")

        session = ResearchAgentSession(session_id, self.content_curator.db_path)
        self.sessions[session_id] = session

        if force_refresh:
            session.context['force_refresh'] = True

        if auto_start_workflow:
            session.context['auto_start_workflow'] = True

        # Check if we should skip morning greeting (for button workflows)
        if skip_morning_greeting:
            session.context['skip_morning_greeting'] = True
            self._mark_morning_greeting_shown()
            import time
            time.sleep(0.1)

        if auto_start_workflow and self._needs_morning_greeting() and not skip_morning_greeting:
            # Store chain config for later use
            if chain_workflow:
                session.context['pending_chain_workflow'] = True
            session.update_state("morning_greeting")
            return self._show_morning_greeting(session)

        if chain_workflow:
            chain_steps = ['collection', 'week_review', 'podcast']
            session.enable_chain_workflow(chain_steps)
            print(f"🔗 Chain workflow enabled: {' → '.join(chain_steps)}")

        # If auto_start_workflow is True, immediately begin the research workflow
        if auto_start_workflow:
            print(f"🚀 Auto-starting research workflow for session: {session_id}")
            session.update_state("initialization")
            return self._check_hot_topics(session)

        # Otherwise, show the welcome menu
        session.update_state("welcome")
        return {
            'response': '''**Ready to help!**

    We can...

    **🔍 Do research & analysis:**
    - "What's going on?" - Analyze today's hot topics
    - "Search for [topic]" - Find current information
    - "Week in review" - Generate weekly analysis

    **📋 Manage your interests:**
    - "Show my interests" - View your research interests
    - "Add [topic] with weight [1-10]" - Add new interest
    - "Change weight of [topic] to [number]" - Update weight

    **💬 Have a discussion:**
    - Ask questions about articles or topics
    - Talk about specific articles by URL

    What would you like to do?''',
            'actions': [],
            'state': 'welcome'
        }

    def _handle_hot_topics_progress(self, session: ResearchAgentSession, message: str) -> Dict:
        """Handle hot topics generation progress - this is for when we generate new topics"""
        return self._auto_advance_from_hot_topics(session)

    def process_message(self, session_id: str, message: str) -> Dict:
        """Process user message - fixed priority order for interests vs workflow detection"""
        session = self.sessions.get(session_id)
        if not session:
            return self.start_session(session_id)

        print(f"🔍 Processing message in state '{session.state}': {message}")

        # 1. HIGHEST PRIORITY: System messages (auto-advance workflows)
        if message in ['hot_topics_complete', 'collection_complete']:
            print(f"🤖 System message detected: {message}")
            return self._handle_system_message(session, message)

        # 2. SECOND PRIORITY: State-specific routing (preserves workflow state)
        if session.state == "welcome":
            result = self._handle_welcome_commands(session, message)
            if 'state' in result:
                session.update_state(result['state'])
            return result
        elif session.state == "hot_topics_generating":
            return self._handle_hot_topics_progress(session, message)
        elif session.state == "interests":
            print("🔄 User message in interests state, auto-advancing...")
            return self._auto_advance_from_hot_topics(session)
        elif session.state == "interests_confirmation":
            return self._handle_interests_confirmation(session, message)
        elif session.state == "refresh_option":
            return self._handle_refresh_option_response(session, message)
        elif session.state == "timeframe":
            return self._handle_timeframe_response(session, message)
        elif session.state == "collection":
            return self._handle_collection_progress(session, message)
        elif session.state == "presentation":
            return self._handle_presentation_interaction(session, message)
        elif session.state == "search":
            return self._handle_search_mode(session, message)
        elif session.state == "morning_greeting":
            return self._handle_morning_greeting_response(session, message)
        elif session.state == "morning_interests":
            return self._handle_morning_interests_response(session, message)
        elif session.state == "morning_interests_confirmation":
            return self._handle_morning_interests_confirmation(session, message)
        elif session.state in ["week_review_chain", "podcast_chain"]:
            print(f"🔗 Chain state '{session.state}' - checking for system messages")
            # For chain states, only handle system messages, ignore user input
            if message in ['week_review_complete', 'podcast_complete']:
                return self._handle_system_message(session, message)
            else:
                # User sent regular message during chain step - just acknowledge
                return {
                    'response': f"⏳ **Chain Step in Progress**\n\nCurrently running: {session.state.replace('_', ' ').title()}\n\nPlease wait for completion...",
                    'actions': [],
                    'state': session.state
                }
        elif session.state == "chat":
            # 3. THIRD PRIORITY: Interests commands in chat mode (but check AFTER workflows)
            if self._is_interests_command(message):
                print(f"📋 Interests command in chat mode: {message}")
                return self._handle_interests_command(session, message)
            else:
                return self._handle_chat_mode(session, message)
        else:
            # Fallback: if unknown state, go to welcome
            print(f"⚠️ Unknown state '{session.state}', resetting to welcome")
            session.update_state("welcome")
            return self._handle_welcome_commands(session, message)

    def _auto_advance_from_collection(self, session: ResearchAgentSession) -> Dict:
        """Automatically advance from collection completion to results presentation"""
        session.update_state("presentation")
        stats = session.context.get("collection_stats", {})

        # Load top articles and show results
        top_articles = self._get_top_articles(session)

        if not top_articles:
            return {
                'response': "📭 **Collection Complete - No Results**\n\nNo articles found matching your criteria. Would you like to:\n• Expand the timeframe\n• Start a new search\n• Modify your interests",
                'actions': [],
                'state': 'presentation'
            }

        # Generate summary and show table
        summary = self._generate_results_summary(stats, top_articles)
        session.update_state("chat", {"top_articles": top_articles})

        return {
            'response': summary,
            'actions': [{'type': 'show_articles_table', 'articles': top_articles}],
            'state': 'chat',
            'show_table': True
        }

    def _handle_interests_response(self, session: ResearchAgentSession, message: str) -> Dict:
        """Step 2: Handle manual user input about interests/timeframe"""
        try:
            # Load user interests from database
            conn = sqlite3.connect(self.content_curator.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT interest, weight FROM user_interests ORDER BY weight DESC')
            interests = [dict(row) for row in cursor.fetchall()]
            conn.close()

            session.update_state("timeframe", {"interests": interests})

            # Format interests display
            if interests:
                interests_list = ", ".join([f"{i['interest']} ({i['weight']:.1f})" for i in interests[:5]])
                interests_text = f"📋 **Your Research Interests:**\n{interests_list}"
                if len(interests) > 5:
                    interests_text += f"\n...and {len(interests) - 5} more"
            else:
                interests_text = "📋 **No research interests configured yet.**\nI'll use general relevance scoring."

            return {
                'response': f"{interests_text}\n\n⏰ **How far back should I look for articles?**\n\n• 24 hours (1 day)\n• 48 hours (2 days) - *recommended*\n• 1 week\n• 2 weeks\n\nJust tell me your preference or say 'default' for 48 hours.",
                'actions': [],
                'state': 'timeframe'
            }

        except Exception as e:
            return {
                'response': f"❌ Error loading interests: {str(e)}\n\nI'll proceed with default settings. How far back should I look for articles? (default: 48 hours)",
                'actions': [],
                'state': 'timeframe'
            }
    
    def _handle_timeframe_response(self, session: ResearchAgentSession, message: str) -> Dict:
        """Step 3: Parse timeframe and start collection"""
        # Parse timeframe from message
        timeframe_hours = self._parse_timeframe(message.lower())
        session.update_state("collection", {"timeframe_hours": timeframe_hours})
        
        timeframe_text = self._format_timeframe(timeframe_hours)
        interests_count = len(session.context.get("interests", []))
        hot_topics_count = len(session.context.get("hot_topics_keywords", []))
        
        return {
            'response': f"🚀 **Starting Research Collection**\n\n📊 **Parameters:**\n• Timeframe: {timeframe_text}\n• Research interests: {interests_count} configured\n• Hot topics boost: {hot_topics_count} keywords\n\nGathering articles from all sources...",
            'actions': [{'type': 'start_collection', 'timeframe_hours': timeframe_hours}],
            'state': 'collection',
            'show_progress': True
        }
    
    def _handle_collection_progress(self, session: ResearchAgentSession, message: str) -> Dict:
        """Handle collection progress updates"""
        # This will be updated when collection completes
        session.update_state("presentation")
        stats = session.context.get("collection_stats", {})
        
        return {
            'response': "✅ **Research Collection Complete**\n\nAnalyzing results and preparing your top findings...",
            'actions': [{'type': 'show_results'}],
            'state': 'presentation'
        }
    
    def _handle_presentation_interaction(self, session: ResearchAgentSession, message: str) -> Dict:
        """Step 4 & 5: Present results and handle interactions"""
        # Load top 10 articles with boost scores
        top_articles = self._get_top_articles(session)
        
        if not top_articles:
            return {
                'response': "📭 **No articles found** matching your criteria.\n\nWould you like to:\n• Expand the timeframe\n• Start a new search\n• Modify your interests",
                'actions': [],
                'state': 'presentation'
            }
        
        # Generate summary
        stats = session.context.get("collection_stats", {})
        summary = self._generate_results_summary(stats, top_articles)
        
        session.update_state("chat", {"top_articles": top_articles})
        
        return {
            'response': summary,
            'actions': [{'type': 'show_articles_table', 'articles': top_articles}],
            'state': 'chat',
            'show_table': True
        }

    def _handle_search_mode(self, session: ResearchAgentSession, message: str) -> Dict:
        """Handle search results and user interaction with them"""
        search_results = session.context.get("search_results", [])
        
        if not search_results:
            return {
                'response': "❌ **Search Error**\n\nNo search results available. Please try another search.",
                'actions': [],
                'state': 'chat'
            }
        
        # Check if user wants to save an article
        if any(phrase in message.lower() for phrase in ['save', 'add to database', 'store this']):
            return self._handle_save_search_result(session, message)
        
        # Check if user wants another search
        if any(phrase in message.lower() for phrase in ['search for', 'find more', 'look up']):
            search_query = self._extract_search_query(message)
            session.context["search_query"] = search_query
            
            return {
                'response': f"🌐 **New Search**\n\nSearching for: \"{search_query}\"\n\nAnalyzing results...",
                'actions': [{'type': 'start_internet_search', 'query': search_query}],
                'state': 'search',
                'show_progress': True
            }
        
        # Regular chat about search results
        search_query = session.context.get("search_query", "")
        enhanced_message = f"[SEARCH RESULTS FOR: {search_query}] {message}"
        response = self.chat_assistant.generate_response(enhanced_message)
        
        return {
            'response': response,
            'actions': [],
            'state': 'search'
        }

    def _extract_search_query(self, message: str) -> str:
        """Extract search query from user message"""
        # Simple extraction logic - can be enhanced
        search_phrases = [
            'search for ', 'find more about ', 'look up ', 'research ', 
            'search the web for ', 'find information about ', 'search online for ',
            'look online for ', 'web search for '
        ]
        
        message_lower = message.lower()
        
        for phrase in search_phrases:
            if phrase in message_lower:
                start_idx = message_lower.find(phrase) + len(phrase)
                query = message[start_idx:].strip()
                # Remove common endings
                for ending in [' please', ' for me', '?', '.']:
                    query = query.rstrip(ending)
                return query[:100]  # Limit query length
        
        # Fallback: return the whole message if no specific indicator found
        return message.strip()[:100]

    def perform_internet_search(self, session_id: str, query: str, max_results: int = 10) -> Dict:
        """Perform internet search and return provider results directly"""
        session = self.sessions.get(session_id)
        if not session:
            return {'error': 'Session not found'}

        try:
            print(f"🔍 Starting internet search for: {query}")

            # Use search provider directly - no content processing
            search_results = self.content_curator.search_provider.search(
                query=query,
                max_results=max_results
            )

            if not search_results:
                session.update_state("chat")
                return {
                    'response': f"🔍 **Search Complete - No Results**\n\nI couldn't find any current information for \"{query}\". This might be because:\n• The topic is very new or specialized\n• Search terms need adjustment\n• Network connectivity issues\n\nTry rephrasing your search or ask me something else!",
                    'state': 'chat',
                    'search_results': []
                }

            # Store results in session and update state
            session.context["search_results"] = search_results
            session.context["search_query"] = query
            session.update_state("search")

            # Generate simple summary
            summary = self._generate_simple_search_summary(search_results, query)

            return {
                'response': summary,
                'actions': [{'type': 'show_search_results', 'results': search_results}],
                'state': 'search',
                'search_results': search_results,
                'show_search_table': True
            }

        except Exception as e:
            print(f"❌ Search error: {e}")
            session.update_state("chat")
            return {
                'response': f"❌ **Search Error**\n\nThere was an error performing the search: {str(e)}\n\nPlease try again with different search terms.",
                'state': 'chat',
                'search_results': []
            }

    def _generate_simple_search_summary(self, search_results: List[Dict], query: str) -> str:
            """Generate a simple summary of search results without AI processing"""
            total_results = len(search_results)

            # Get top result info
            top_result = search_results[0]
            top_title = top_result['title'][:60] + "..." if len(top_result['title']) > 60 else top_result['title']

            # Count unique sources
            sources = set(result['source'] for result in search_results)

            summary = f"""🌐 **Internet Search Results for "{query}"**
    
        📊 **Search Summary:**
        - Found {total_results} relevant articles
        - Sources: {len(sources)} different websites
    
        🏆 **Top Result:** {top_title}
           Source: {top_result['source']}
    
        💬 **What would you like to do?**
        - Ask me questions about these results
        - Say "save" to add articles to your database
        - Request another search on a different topic
    
        📋 **Search Results:**"""

            return summary


    def _generate_search_summary(self, search_results: List[Dict], query: str) -> str:
        """Generate a summary of search results"""
        total_results = len(search_results)
        
        if total_results == 0:
            return f"🔍 **No results found for \"{query}\"**"
        
        # Calculate average relevance
        avg_relevance = sum(result.get('relevance_score', 0) for result in search_results) / total_results
        
        # Get top result info
        top_result = search_results[0]
        top_title = top_result['title'][:60] + "..." if len(top_result['title']) > 60 else top_result['title']
        
        # Count sources
        sources = set(result['source'] for result in search_results)
        
        summary = f"""🌐 **Internet Search Results for "{query}"**

📊 **Search Summary:**
• Found {total_results} relevant articles
• Average relevance: {avg_relevance:.1f}/10
• Sources: {len(sources)} different websites

🏆 **Top Result:** {top_title}
   Source: {top_result['source']}
   Relevance: {top_result.get('relevance_score', 0):.1f}/10

💬 **What would you like to do?**
• Ask me questions about these results
• Say "save" to add the top article to your database
• Request another search on a different topic

📋 **Top Search Results:**"""

        return summary

    def _parse_timeframe(self, message: str) -> int:
        """Parse timeframe from user message"""
        if any(word in message for word in ['default', '48', 'two days', '2 days']):
            return 48
        elif any(word in message for word in ['24', 'one day', '1 day', 'today']):
            return 24
        elif any(word in message for word in ['week', '7 days', 'weekly']):
            return 168
        elif any(word in message for word in ['2 weeks', 'two weeks', '14 days']):
            return 336
        else:
            return 48  # default
    
    def _format_timeframe(self, hours: int) -> str:
        """Format hours into readable timeframe"""
        if hours <= 24:
            return "24 hours"
        elif hours <= 48:
            return "48 hours (2 days)"
        elif hours <= 168:
            return "1 week"
        elif hours <= 336:
            return "2 weeks"
        else:
            return f"{hours} hours"
    
    def _get_top_articles(self, session: ResearchAgentSession) -> List[Dict]:
        """Get top 10 articles with relevance + hot topics boost"""
        try:
            conn = sqlite3.connect(self.content_curator.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            timeframe_hours = session.context.get("timeframe_hours", 48)
            since_date = (datetime.now() - timedelta(hours=timeframe_hours)).isoformat()
            
            cursor.execute('''
                SELECT *, 
                       (relevance_score + COALESCE(relevance_boost, 0)) as total_relevance,
                       COALESCE(relevance_boost, 0) as boost_score
                FROM content 
                WHERE added_date > ?
                ORDER BY total_relevance DESC, relevance_score DESC, published_date DESC 
                LIMIT 100
            ''', (since_date,))
            
            articles = [dict(row) for row in cursor.fetchall()]
            conn.close()
            return articles
            
        except Exception as e:
            print(f"Error getting top articles: {e}")
            return []
    
    def _generate_results_summary(self, stats: Dict, top_articles: List[Dict]) -> str:
        """Generate summary of research results"""
        total_articles = len(top_articles)
        if total_articles == 0:
            return "📭 **No articles found** for your research criteria."
        
        # Count boosted articles
        boosted_count = sum(1 for article in top_articles if article.get('boost_score', 0) > 0)
        avg_relevance = sum(article.get('relevance_score', 0) for article in top_articles) / total_articles
        
        # Top article info
        top_article = top_articles[0] if top_articles else None
        top_title = top_article['title'][:60] + "..." if top_article and len(top_article['title']) > 60 else top_article['title']
        
        summary = f"""🎯 **Research Results Summary**

📊 **Collection Stats:**
• Found {total_articles} top-ranked articles
• Average relevance: {avg_relevance:.1f}/10
• Hot topics boost: {boosted_count} articles boosted

🏆 **Top Finding:** {top_title}
   Relevance: {top_article.get('total_relevance', 0):.1f}/10

💬 **Available Commands:**
• Discuss any article by clicking "Discuss"
• Ask me to "search for [topic]" to find more current info
• Request analysis or comparisons

📋 **Your Top 10 Research Articles**
Click any article below to read the full text or discuss it with me."""

        return summary

    def update_collection_stats(self, session_id: str, stats: Dict):
        """Update collection statistics for a session"""
        if session_id in self.sessions:
            self.sessions[session_id].context["collection_stats"] = stats

    def update_search_progress(self, session_id: str, progress_data: Dict):
        """Update search progress for a session"""
        if session_id in self.sessions:
            session = self.sessions[session_id]
            if 'search_progress' not in session.context:
                session.context['search_progress'] = {}
            session.context['search_progress'].update(progress_data)

    def start_forced_refresh(self, session_id: str, timeframe_hours: int = 48) -> Dict:
        """Start a forced refresh collection, bypassing any existing hot topics boost data"""
        try:
            session = self.sessions.get(session_id)
            if not session:
                session = ResearchAgentSession(session_id, self.content_curator.db_path)
                self.sessions[session_id] = session

            # Mark as forced refresh to bypass all boost checking
            session.update_state("collection", {
                "timeframe_hours": timeframe_hours,
                "forced_refresh": True,
                "skip_boost_check": True
            })

            print(f"🔄 Starting forced refresh for session {session_id}")

            return {
                'response': f"🔄 **Forced Refresh Started**\n\nBypassing existing hot topics data and starting fresh collection...\n\n📊 **Parameters:**\n• Timeframe: {timeframe_hours} hours\n• Mode: Forced refresh\n• Hot topics: Will generate new analysis\n\nGathering articles from all sources...",
                'actions': [{'type': 'start_collection', 'timeframe_hours': timeframe_hours, 'forced': True}],
                'state': 'collection',
                'show_progress': True,
                'forced_refresh': True
            }

        except Exception as e:
            return {
                'response': f"❌ **Forced Refresh Error**\n\nError starting forced refresh: {str(e)}",
                'actions': [],
                'state': 'chat'
            }

    def _handle_article_discussion_request(self, session: ResearchAgentSession, article_url: str,
                                           article_title: str = None) -> Dict:
        """Handle request to discuss a specific article - with full content processing"""
        try:
            # Get comprehensive article info for chat
            article_info = self._prepare_article_for_discussion(article_url, article_title)

            if 'error' in article_info:
                return {
                    'response': f"❌ **Article Not Found**\n\n{article_info['error']}\n\nPlease make sure the article URL is correct.",
                    'actions': [],
                    'state': session.state
                }

            # Update session to track current article discussion
            session.context['current_article'] = article_info
            session.context['discussion_mode'] = 'article'

            return {
                'response': article_info['chat_intro'],
                'actions': [],
                'state': 'chat',
                'article_loaded': True
            }

        except Exception as e:
            return {
                'response': f"❌ **Error Loading Article**\n\nThere was an error preparing the article for discussion: {str(e)}",
                'actions': [],
                'state': session.state
            }

    def _prepare_article_for_discussion(self, article_url: str, article_title: str = None) -> Dict:
        """Comprehensive article preparation - fetch, summarize, and store"""
        try:
            conn = sqlite3.connect(self.content_curator.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            # First check if we have processed version with summary
            cursor.execute('SELECT * FROM content WHERE url = ?', (article_url,))
            processed_article = cursor.fetchone()

            if processed_article and processed_article['summary'] and len(processed_article['summary'].strip()) > 20:
                # We have a good processed version
                conn.close()
                return {
                    'title': processed_article['title'],
                    'source': processed_article['source'],
                    'url': processed_article['url'],
                    'published_date': processed_article['published_date'],
                    'content': processed_article['content'] or '',
                    'ai_summary': processed_article['summary'],
                    'relevance_score': processed_article['relevance_score'],
                    'has_ai_summary': True,
                    'chat_intro': f"📖 **Discussing: {processed_article['title']}**\n\n**Source:** {processed_article['source']}\n\n**AI Summary:** {processed_article['summary']}\n\n**Relevance Score:** {processed_article['relevance_score']:.1f}/10\n\nWhat would you like to discuss about this article?"
                }

            # Check raw feeds table
            cursor.execute('SELECT * FROM raw_feeds WHERE url = ?', (article_url,))
            raw_article = cursor.fetchone()

            article_data = None
            if raw_article:
                article_data = {
                    'title': raw_article['title'],
                    'source': raw_article['source'],
                    'url': raw_article['url'],
                    'published_date': raw_article['published_date'],
                    'content': raw_article['content'] or raw_article['full_content'] or ''
                }

            conn.close()

            # If we don't have the article in our database, scrape it
            if not article_data:
                print(f"   🌐 Article not in database, scraping: {article_url}")
                scraped_content = self.content_curator.scrape_webpage(article_url)

                if not scraped_content:
                    return {'error': f'Could not access article content from {article_url}'}

                # Create article data from scraped content
                article_data = {
                    'title': article_title or self._extract_title_from_url(article_url),
                    'source': self._extract_source_from_url(article_url),
                    'url': article_url,
                    'published_date': datetime.now().isoformat(),
                    'content': scraped_content
                }

                # Save to raw_feeds for future reference
                self._save_scraped_article(article_data)

            # If we have content but no processed summary, generate one
            if not processed_article or not processed_article.get('summary'):
                print(f"   🧠 Generating summary for: {article_data['title'][:50]}...")

                # Use the content curator's summary generation
                summary, relevance_score = self.content_curator.generate_summary_and_relevance(article_data)

                # Save the processed version
                self._save_processed_article(article_data, summary, relevance_score)

                article_data.update({
                    'ai_summary': summary,
                    'relevance_score': relevance_score,
                    'has_ai_summary': True
                })

            # Create chat intro
            chat_intro = f"""📖 **Discussing: {article_data['title']}**

    **Source:** {article_data['source']}

    **AI Summary:** {article_data.get('ai_summary', 'Summary being generated...')}

    **Relevance Score:** {article_data.get('relevance_score', 0):.1f}/10

    I've analyzed this article and I'm ready to discuss it with you. What aspects interest you most?"""

            article_data['chat_intro'] = chat_intro
            article_data['has_ai_summary'] = True

            return article_data

        except Exception as e:
            print(f"   ❌ Error preparing article for discussion: {e}")
            return {'error': f'Error processing article: {str(e)}'}

    def _extract_title_from_url(self, url: str) -> str:
        """Extract a basic title from URL if none provided"""
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            path_parts = parsed.path.strip('/').split('/')
            if path_parts and path_parts[-1]:
                title = path_parts[-1].replace('-', ' ').replace('_', ' ')
                return title.title()
            return f"Article from {parsed.netloc}"
        except:
            return "Article Discussion"

    def _extract_source_from_url(self, url: str) -> str:
        """Extract source name from URL"""
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            # Remove common prefixes
            if domain.startswith('www.'):
                domain = domain[4:]
            return domain.replace('.com', '').replace('.org', '').replace('.edu', '').title()
        except:
            return "Unknown Source"

    def _save_scraped_article(self, article_data: Dict):
        """Save scraped article to raw_feeds table"""
        try:
            conn = sqlite3.connect(self.content_curator.db_path)
            cursor = conn.cursor()

            content_hash = hashlib.md5(article_data.get('content', '').encode()).hexdigest()

            cursor.execute('''
                INSERT OR IGNORE INTO raw_feeds 
                (title, content, url, published_date, source, full_content, search_topic, content_hash)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                article_data['title'],
                article_data['content'][:1000],  # Truncated content
                article_data['url'],
                article_data['published_date'],
                article_data['source'],
                article_data['content'],  # Full content
                'discussion',
                content_hash
            ))

            conn.commit()
            conn.close()
            print(f"   ✅ Saved scraped article to database: {article_data['title']}")

        except Exception as e:
            print(f"   ⚠️  Warning: Could not save scraped article: {e}")

    def _save_processed_article(self, article_data: Dict, summary: str, relevance_score: float):
        """Save processed article with summary to content table"""
        try:
            conn = sqlite3.connect(self.content_curator.db_path)
            cursor = conn.cursor()

            cursor.execute('''
                INSERT OR REPLACE INTO content 
                (source, title, url, content, summary, relevance_score, published_date, search_topic)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                article_data['source'],
                article_data['title'],
                article_data['url'],
                article_data['content'],
                summary,
                relevance_score,
                article_data['published_date'],
                'discussion'
            ))

            conn.commit()
            conn.close()
            print(f"   ✅ Saved processed article with summary: {article_data['title']}")

        except Exception as e:
            print(f"   ❌ Error saving processed article: {e}")

    def _handle_chat_mode(self, session: ResearchAgentSession, message: str) -> Dict:
        """Enhanced chat mode with better article context"""
        # 1. Check for save commands first
        if self._is_save_command(message):
            return self._handle_save_current_article(session)

        # 2. Check for URLs in message
        urls = self._extract_urls(message)
        if urls:
            return self._handle_url_analysis(session, urls[0], message)

        # 3. Existing search triggers
        search_indicators = [
            'search for', 'find more', 'look up', 'research', 'search the web',
            'find information', 'search online', 'look online', 'web search'
        ]

        if any(indicator in message.lower() for indicator in search_indicators):
            # Extract search query from message
            search_query = self._extract_search_query(message)
            session.update_state("search", {"search_query": search_query, "search_context": "user_request"})

            return {
                'response': f"🌐 **Starting Internet Search**\n\nSearching for: \"{search_query}\"\n\nI'll find current information and analyze the results for you...",
                'actions': [{'type': 'start_internet_search', 'query': search_query}],
                'state': 'search',
                'show_progress': True
            }

        # Enhanced chat with article context
        current_article = session.context.get("current_article")
        discussion_mode = session.context.get("discussion_mode")

        # Prepare context for the chat assistant
        if current_article and discussion_mode == 'article':
            # We're discussing a specific article
            enhanced_message = f"""[ARTICLE DISCUSSION CONTEXT]
    Title: {current_article.get('title', 'Unknown')}
    Source: {current_article.get('source', 'Unknown')}
    Summary: {current_article.get('ai_summary', 'No summary available')}
    Content Available: {'Yes' if current_article.get('content') else 'No'}

    USER MESSAGE: {message}"""

            # Use chat assistant with article context
            response = self.chat_assistant.generate_response(enhanced_message)

        else:
            # Regular chat mode
            articles_context = session.context.get("top_articles", [])
            if articles_context:
                enhanced_message = f"[RESEARCH CONTEXT: User has {len(articles_context)} recent articles available] {message}"
            else:
                enhanced_message = message

            response = self.chat_assistant.generate_response(enhanced_message)

        return {
            'response': response,
            'actions': [],
            'state': 'chat'
        }

    def _is_save_command(self, message: str) -> bool:
        """Detect if message is a save command"""
        message_lower = message.lower().strip()
        save_triggers = [
            'save it', 'save this', 'save', 'keep it', 'remember it',
            'add to database', 'store this', 'save article', 'add this',
            'keep this article', 'remember this', 'save this article'
        ]
        return any(trigger in message_lower for trigger in save_triggers)

    def _extract_urls(self, message: str) -> List[str]:
        """Extract URLs from message"""
        url_pattern = r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:\w)*)?)?'
        return re.findall(url_pattern, message)

    def _handle_url_analysis(self, session: ResearchAgentSession, url: str, original_message: str) -> Dict:
        """Handle URL analysis with PDF detection"""
        try:
            # NEW: Check if it's a PDF first
            is_pdf = self._is_pdf_url_simple(url)

            if is_pdf and not HAS_PDF_SUPPORT:
                return {
                    'response': f"📄 **PDF Detected but Not Supported**\n\nI detected that this URL points to a PDF file:\n{url}\n\nTo enable PDF support:\n1. Install dependencies: `pip install pdfplumber PyPDF2 pymupdf`\n2. Ensure `pdf_parser.py` is in the project directory\n3. Restart the application\n\nAlternatively, you can copy/paste text from the PDF for me to analyze.",
                    'actions': [],
                    'state': session.state
                }

            # EXISTING: Use your current article preparation logic (works for both PDFs and web pages now)
            article_data = self._prepare_article_for_discussion(url, original_message)

            if 'error' in article_data:
                return {
                    'response': f"❌ **URL Analysis Failed**\n\n{article_data['error']}\n\nPlease check the URL and try again.",
                    'actions': [],
                    'state': session.state
                }

            # EXISTING: Store as current article (your existing logic)
            session.context['current_article'] = {
                'url': article_data['url'],
                'title': article_data['title'],
                'source': article_data['source'],
                'content': article_data.get('content', ''),
                'ai_summary': article_data.get('ai_summary', ''),
                'relevance_score': article_data.get('relevance_score', 0),
                'boost_score': 0,
                'published_date': article_data.get('published_date', ''),
                'ready_to_save': True,
                'content_type': 'pdf' if is_pdf else 'webpage'  # NEW: Track content type
            }

            # EXISTING: Format analysis display (your existing logic)
            response = self._format_article_analysis_display(article_data)

            return {
                'response': response,
                'actions': [],
                'state': 'chat',
                'article_analyzed': True
            }

        except Exception as e:
            return {
                'response': f"❌ **URL Analysis Error**\n\nError analyzing URL: {str(e)}",
                'actions': [],
                'state': session.state
            }

    def _format_article_analysis_display(self, article_data: Dict) -> str:
        """Format the article analysis for display"""
        # Get user interests for relevance matching
        try:
            conn = sqlite3.connect(self.content_curator.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT interest FROM user_interests WHERE weight > 5 ORDER BY weight DESC LIMIT 3')
            top_interests = [row['interest'] for row in cursor.fetchall()]
            conn.close()
        except:
            top_interests = []

        # Calculate hot topics boost (reuse existing logic)
        boost_score = 0
        hot_topic = ""
        try:
            today_date = datetime.now().strftime('%Y-%m-%d')
            boost_data = self.content_curator.check_hot_topics_boost_status(today_date)
            if boost_data.get('keywords_used'):
                keywords = boost_data['keywords_used']

                # Combine article text for keyword matching (same logic as content_curator)
                article_text = f"{article_data.get('title', '')} {article_data.get('ai_summary', '')}".lower()

                # Count keyword matches (following the same pattern as rescore_with_hot_topics)
                keyword_matches = 0
                matched_keywords = []

                for keyword in keywords:
                    if keyword.lower() in article_text:
                        keyword_matches += 1
                        matched_keywords.append(keyword)

                # Apply same scoring logic: each match = +2 boost points
                boost_score = keyword_matches * 2.0
                hot_topic = matched_keywords[0] if matched_keywords else ""

        except Exception as e:
            print(f"Warning: Could not calculate hot topics boost: {e}")
            boost_score = 0
            hot_topic = ""

        # Format interests text
        interests_text = "', '".join(top_interests[:2]) if top_interests else "general topics"

        # Format boost text
        boost_text = f"**Hot Topics Boost:** +{boost_score:.1f} (matches today's trending topic '{hot_topic}')" if hot_topic else "**Hot Topics Boost:** +0.0 (no trending topic matches)"

        return f"""📖 **Article Analysis Complete**

    **Title:** {article_data['title']}
    **Source:** {article_data['source']}
    **Summary:** {article_data.get('ai_summary', 'Analysis in progress...')}
    **Relevance Score:** {article_data.get('relevance_score', 0):.1f}/10 (matches your '{interests_text}' interests)
    {boost_text}

    What would you like to discuss about this article?"""

    def _calculate_article_boost_score(self, article_data: Dict) -> Tuple[float, str]:
        """Calculate boost score for an article using same logic as content_curator"""
        try:
            today_date = datetime.now().strftime('%Y-%m-%d')
            boost_data = self.content_curator.check_hot_topics_boost_status(today_date)

            if not boost_data.get('keywords_used'):
                return 0.0, ""

            keywords = boost_data['keywords_used']
            article_text = f"{article_data.get('title', '')} {article_data.get('ai_summary', '')}".lower()

            keyword_matches = 0
            matched_keywords = []

            for keyword in keywords:
                if keyword.lower() in article_text:
                    keyword_matches += 1
                    matched_keywords.append(keyword)

            boost_score = keyword_matches * 2.0  # Same as content_curator: each match = +2
            matched_keyword = matched_keywords[0] if matched_keywords else ""

            return boost_score, matched_keyword

        except Exception as e:
            print(f"Error calculating article boost score: {e}")
            return 0.0, ""

    def _handle_save_current_article(self, session: ResearchAgentSession) -> Dict:
        """Handle saving the current article to database"""
        current_article = session.context.get('current_article')

        if not current_article or not current_article.get('ready_to_save'):
            return {
                'response': "I don't have a current article loaded. What would you like me to save? You can share a URL or tell me about an article you'd like me to find.",
                'actions': [],
                'state': session.state
            }

        try:
            # Prepare article data for database save
            article_for_save = {
                'title': current_article['title'],
                'url': current_article['url'],
                'source': current_article['source'],
                'content': current_article.get('content', ''),
                'summary': current_article.get('ai_summary', ''),
                'relevance_score': current_article.get('relevance_score', 0),
                'published_date': current_article.get('published_date', datetime.now().isoformat())
            }

            # Use existing save method from content_curator
            save_result = self.content_curator.add_search_result_to_database(article_for_save)

            if save_result.get('success', False):
                # Calculate total score for display
                try:
                    boost_score, matched_keyword = self._calculate_article_boost_score(current_article)
                    current_article['boost_score'] = boost_score
                    current_article['matched_hot_topic'] = matched_keyword
                except:
                    current_article['boost_score'] = 0
                    current_article['matched_hot_topic'] = ""

                # Calculate total score for display
                total_score = current_article.get('relevance_score', 0) + current_article.get('boost_score', 0)

                return {
                    'response': f"✅ **Article Saved!** Added '{current_article['title']}' to your database with total relevance score {total_score:.1f}/10.",
                    'actions': [],
                    'state': 'chat'
                }
            else:
                return {
                    'response': f"⚠️ **Save Failed** - {save_result.get('message', 'Unknown error')}\n\nThe article might already be in your database.",
                    'actions': [],
                    'state': 'chat'
                }

        except Exception as e:
            return {
                'response': f"❌ **Error Saving Article**\n\nThere was an error saving the article: {str(e)}",
                'actions': [],
                'state': 'chat'
            }

    def _handle_interests_command(self, session: ResearchAgentSession, message: str) -> Dict:
        """Use LLM to understand and handle interests management"""

        # Get current interests for context
        try:
            conn = sqlite3.connect(self.content_curator.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT interest, weight FROM user_interests ORDER BY weight DESC')
            current_interests = [f"{row['interest']} (weight: {row['weight']:.1f})" for row in cursor.fetchall()]
            conn.close()

            interests_context = "\n".join(current_interests) if current_interests else "No interests configured yet"
        except:
            interests_context = "Error loading interests"

        # Ask LLM to interpret the request
        prompt = f"""You are helping manage a user's research interests. Current interests:

    {interests_context}

    User request: "{message}"

    Please analyze this request and respond with JSON only:

    For SHOW/LIST requests:
    {{"action": "show"}}

    For ADD requests:
    {{"action": "add", "interest": "topic name", "weight": 5.0, "confirmation": "Add 'topic name' with weight 5.0?"}}

    For REMOVE/DELETE requests:
    {{"action": "remove", "interest": "closest matching interest name", "confirmation": "Remove 'interest name'?"}}

    For WEIGHT CHANGE requests:
    {{"action": "update_weight", "interest": "closest matching interest name", "weight": 7.5, "confirmation": "Change weight of 'interest name' to 7.5?"}}

    For HELP requests:
    {{"action": "help"}}

    Use these rules:
    - For ADD: If no weight specified, use 5.0. Weight must be 0.1-10.0
    - For REMOVE/UPDATE: Find the closest matching interest from the current list
    - Make confirmations clear and friendly
    - Only return valid JSON, no other text"""

        try:
            # Get LLM response
            response = ollama.chat(
                model=self.ollama_model,
                messages=[{"role": "user", "content": prompt}]
            )

            # Parse the JSON response
            import json
            intent = json.loads(response['message']['content'].strip())

            # Handle the action
            if intent['action'] == 'show':
                return self._show_interests(session)
            elif intent['action'] == 'help':
                return self._show_interests_help(session)
            elif intent['action'] in ['add', 'remove', 'update_weight']:
                session.update_state('interests_confirmation', {
                    'pending_interests_action': intent
                })

                return {
                    'response': f"🤔 **Confirm Interest Management**\n\n{intent['confirmation']}\n\nSay 'yes' to proceed or 'no' to cancel.",
                    'actions': [],
                    'state': 'interests_confirmation'
                }
            else:
                return {
                    'response': "❌ **Couldn't understand the request**\n\nPlease try commands like:\n• 'Show my interests'\n• 'Add technology with weight 8'\n• 'Remove AI interest'\n• 'Change weight of climate to 9'",
                    'actions': [],
                    'state': session.state
                }

        except Exception as e:
            print(f"LLM interests parsing error: {e}")
            return {
                'response': "❌ **Error understanding request**\n\nPlease try a clearer command like:\n• 'Show my interests'\n• 'Add [topic] with weight [1-10]'\n• 'Remove [topic] interest'",
                'actions': [],
                'state': session.state
            }

    def _handle_interests_confirmation(self, session: ResearchAgentSession, message: str) -> Dict:
        """Handle yes/no confirmation for interests actions"""
        message_lower = message.lower().strip()

        if message_lower in ['yes', 'y', 'confirm', 'ok', 'proceed']:
            # Execute the pending action
            pending = session.context.get('pending_interests_action')
            if not pending:
                session.update_state('chat')
                return {
                    'response': "❌ **No pending action**\n\nPlease make a new interests request.",
                    'actions': [],
                    'state': 'chat'
                }

            return self._execute_interests_action(session, pending)

        elif message_lower in ['no', 'n', 'cancel', 'abort']:
            # Cancel the action
            session.context.pop('pending_interests_action', None)
            session.update_state('chat')
            return {
                'response': "✅ **Action cancelled**\n\nWhat else can I help you with?",
                'actions': [],
                'state': 'chat'
            }
        else:
            return {
                'response': "🤔 **Please confirm**\n\nSay 'yes' to proceed or 'no' to cancel the interests action.",
                'actions': [],
                'state': 'interests_confirmation'
            }

    def _execute_interests_action(self, session: ResearchAgentSession, action: Dict) -> Dict:
        """Execute the confirmed interests action"""
        try:
            conn = sqlite3.connect(self.content_curator.db_path)
            cursor = conn.cursor()

            if action['action'] == 'add':
                # Add or update interest
                cursor.execute('SELECT id FROM user_interests WHERE LOWER(interest) = LOWER(?)',
                               (action['interest'],))
                existing = cursor.fetchone()

                if existing:
                    cursor.execute('UPDATE user_interests SET weight = ? WHERE id = ?',
                                   (action['weight'], existing[0]))
                    result_msg = f"✅ **Interest Updated**\n\n**{action['interest']}** weight set to {action['weight']:.1f}"
                else:
                    cursor.execute('INSERT INTO user_interests (interest, weight) VALUES (?, ?)',
                                   (action['interest'], action['weight']))
                    weight_bar = "🟦" * min(int(action['weight']), 10)
                    result_msg = f"✅ **Interest Added**\n\n**{action['interest']}** (Weight: {action['weight']:.1f}) {weight_bar}"

            elif action['action'] == 'remove':
                cursor.execute('DELETE FROM user_interests WHERE LOWER(interest) = LOWER(?)',
                               (action['interest'],))
                if cursor.rowcount > 0:
                    result_msg = f"✅ **Interest Removed**\n\n**{action['interest']}** has been deleted from your interests."
                else:
                    result_msg = f"❌ **Interest not found:** {action['interest']}"

            elif action['action'] == 'update_weight':
                cursor.execute('UPDATE user_interests SET weight = ? WHERE LOWER(interest) = LOWER(?)',
                               (action['weight'], action['interest']))
                if cursor.rowcount > 0:
                    old_bar = "🟦" * min(int(5), 10)  # Placeholder
                    new_bar = "🟦" * min(int(action['weight']), 10)
                    result_msg = f"✅ **Weight Updated**\n\n**{action['interest']}** weight changed to {action['weight']:.1f} {new_bar}"
                else:
                    result_msg = f"❌ **Interest not found:** {action['interest']}"

            conn.commit()
            conn.close()

            # Clear pending action
            session.context.pop('pending_interests_action', None)
            if session.context.get('in_morning_flow', False):
                # Return to morning interests state
                session.update_state('morning_interests')
                return {
                    'response': result_msg + "\n\n**Say 'done' when finished or continue adjusting interests.**",
                    'actions': [],
                    'state': 'morning_interests'
                }
            else:
                # Normal interests command outside morning flow
                session.update_state('chat')
                return {
                    'response': result_msg + "\n\n**Want to see all interests?** Say 'show my interests'",
                    'actions': [],
                    'state': 'chat'
                }

        except Exception as e:
            session.context.pop('pending_interests_action', None)
            session.update_state('chat')
            return {
                'response': f"❌ **Database Error**\n\nFailed to execute action: {str(e)}",
                'actions': [],
                'state': session.state
            }

    def _show_interests(self, session: ResearchAgentSession) -> Dict:
            """Display current interests"""
            try:
                conn = sqlite3.connect(self.content_curator.db_path)
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM user_interests ORDER BY weight DESC')
                interests = [dict(row) for row in cursor.fetchall()]
                conn.close()

                if not interests:
                    response = """📋 **Your Research Interests**

    ❌ **No interests configured yet**

    Interests help me score and rank articles based on your preferences. Higher weights (1-10) give more relevance boost.

    **Add interests with commands like:**
    • "Add artificial intelligence with weight 8.5"
    • "Add technology weight 7.0"
    • "Add climate change interest, weight 9"

    **Want to get started?** Try: "Add [topic] with weight [1-10]" """
                else:
                    interests_list = []
                    total_weight = sum(i['weight'] for i in interests)

                    for interest in interests:
                        weight_bar = "🟦" * min(int(interest['weight']), 10)  # Visual weight indicator
                        interests_list.append(
                            f"• **{interest['interest']}** (Weight: {interest['weight']:.1f}) {weight_bar}")

                    response = f"""📋 **Your Research Interests** ({len(interests)} configured)

    {chr(10).join(interests_list)}

    **Manage your interests:**
    • "Add [topic] with weight [1-10]" - Add new interest
    • "Change weight of [topic] to [number]" - Update weight  
    • "Remove [topic] interest" - Delete interest
    • "Add technology weight 8.5" - Quick add example

    Higher weights mean articles matching that interest get more relevance points!"""

                return {
                    'response': response,
                    'actions': [],
                    'state': session.state
                }

            except Exception as e:
                return {
                    'response': f"❌ **Error Loading Interests**\n\nDatabase error: {str(e)}",
                    'actions': [],
                    'state': session.state
                }

    def _show_interests_help(self, session: ResearchAgentSession) -> Dict:
            """Show help for interests commands"""
            response = """📋 **Interests Management Help**

    **View Interests:**
    • "Show my interests" - List all configured interests
    • "What are my interests?" - Same as above

    **Add Interests:**
    • "Add artificial intelligence with weight 8.5"
    • "Add technology weight 7.0" 
    • "New interest: climate change, weight 9"

    **Modify Weights:**
    • "Change weight of technology to 6.5"
    • "Set AI weight to 9.0"
    • "Update artificial intelligence weight to 8"

    **Remove Interests:**
    • "Remove technology interest"
    • "Delete AI interest"

    **Weight Guidelines:**
    • 1-3: Low interest (slight boost)
    • 4-6: Medium interest (moderate boost)  
    • 7-10: High interest (strong boost)

    Interests help me score articles - higher weights mean matching content gets ranked higher in your results!"""

            return {
                'response': response,
                'actions': [],
                'state': session.state
            }

    def _handle_welcome_commands(self, session: ResearchAgentSession, message: str) -> Dict:
        """Handle commands in the welcome state - fixed priority order"""
        message_lower = message.lower().strip()

        # 1. HIGHEST PRIORITY: Research workflow triggers (check FIRST)
        research_triggers = [
            "what's going on", "whats going on", "current events",
            "hot topics", "analyze today", "today's analysis"
        ]
        if any(trigger in message_lower for trigger in research_triggers):
            print(f"🎯 Detected research workflow trigger: {message}")
            return self._check_hot_topics(session)

        # 2. SECOND PRIORITY: Interests commands (check AFTER research triggers)
        if self._is_interests_command(message):
            print(f"📋 Detected interests command: {message}")
            return self._handle_interests_command(session, message)

        # 3. THIRD PRIORITY: Search triggers
        search_triggers = ["search for", "find", "look up", "search the web", "search online"]
        if any(trigger in message_lower for trigger in search_triggers):
            search_query = self._extract_search_query(message)
            session.update_state("search", {"search_query": search_query})
            return {
                'response': f"🌐 **Starting Internet Search**\n\nSearching for: \"{search_query}\"...",
                'actions': [{'type': 'start_internet_search', 'query': search_query}],
                'state': 'search',
                'show_progress': True
            }

        # 4. DEFAULT: General chat mode
        session.update_state("chat")
        return self._handle_chat_mode(session, message)

    def _is_pdf_url_simple(self, url: str) -> bool:
        """Simple PDF URL detection (fallback if pdf_parser not available)"""
        if HAS_PDF_SUPPORT:
            return is_pdf_url(url)
        else:
            # Simple fallback: just check file extension
            return url.lower().endswith('.pdf')


    def _handle_chain_step_completion(self, session: ResearchAgentSession, completed_step: str) -> Dict:
        """Handle completion of a chain step and advance to next"""
        print(f"🔗 Chain step '{completed_step}' completed")

        # Store step results
        if completed_step == 'collection':
            step_data = {
                'collection_stats': session.context.get('collection_stats', {}),
                'top_articles': self._get_top_articles(session)
            }
        elif completed_step == 'week_review':
            step_data = session.context.get('week_review_data', {})
        elif completed_step == 'podcast':
            step_data = session.context.get('podcast_files', {})
        else:
            step_data = {}

        session.store_chain_step_data(completed_step, step_data)

        # Advance to next step
        next_step = session.advance_chain_step()

        if next_step:
            return self._start_chain_step(session, next_step)
        else:
            # Chain complete - show final presentation
            return self._handle_chain_completion(session)


    def _start_chain_step(self, session: ResearchAgentSession, step: str) -> Dict:
        """Start the next step in the chain"""
        print(f"🔗 Starting chain step: {step}")

        session.chain_config['current_step'] = step

        if step == 'week_review':
            session.update_state('week_review_chain')
            return {
                'response': '📊 **Chain Step 2: Week in Review**\n\nAnalyzing past 7 days of current events...',
                'actions': [{'type': 'start_week_review_chain'}],
                'state': 'week_review_chain',
                'show_progress': True,
                'chain_step': step
            }

        elif step == 'podcast':
            session.update_state('podcast_chain')
            return {
                'response': '🎙️ **Chain Step 3: Podcast Generation**\n\nCreating daily podcast from top articles...',
                'actions': [{'type': 'start_podcast_chain'}],
                'state': 'podcast_chain',
                'show_progress': True,
                'chain_step': step
            }

        else:
            # Unknown step - skip to next
            return self._handle_chain_step_completion(session, step)


    def _handle_chain_completion(self, session: ResearchAgentSession) -> Dict:
        """Handle completion of entire chain workflow"""
        print(f"🎉 Chain workflow completed for session {session.session_id}")

        # Collect all chain results
        collection_data = session.chain_config['step_data'].get('collection', {})
        week_review_data = session.chain_config['step_data'].get('week_review', {})
        podcast_data = session.chain_config['step_data'].get('podcast', {})

        # Generate comprehensive summary
        summary = self._generate_chain_completion_summary(collection_data, week_review_data, podcast_data)

        # Get articles for display
        top_articles = collection_data.get('top_articles', [])

        session.update_state("chat", {
            "chain_completed": True,
            "top_articles": top_articles,
            "week_review_data": week_review_data,
            "podcast_files": podcast_data
        })

        return {
            'response': summary,
            'actions': [{'type': 'show_articles_table', 'articles': top_articles}],
            'state': 'chat',
            'show_table': True,
            'chain_completed': True,
            'chain_results': {
                'collection': collection_data,
                'week_review': week_review_data,
                'podcast': podcast_data
            }
        }


    def _generate_chain_completion_summary(self, collection_data: Dict, week_review_data: Dict, podcast_data: Dict) -> str:
        """Generate summary of complete chain workflow results"""

        articles_count = len(collection_data.get('top_articles', []))
        collection_stats = collection_data.get('collection_stats', {})

        summary = f"""🎉 **Complete Research Chain Finished!**
    
    📊 **Multi-Step Analysis Summary:**
    
    **🔍 Step 1 - Research Collection:**
    - {articles_count} top-ranked articles identified
    - {collection_stats.get('ai_processed', 0)} articles processed with AI
    - Hot topics boost applied to relevant content
    
    **📈 Step 2 - Week in Review:**
    - {week_review_data.get('total_days_analyzed', 0)} days of analysis consolidated
    - {len(week_review_data.get('keyword_counts', {}))} keyword trends identified
    - Comprehensive weekly summary generated
    
    **🎙️ Step 3 - Podcast Generation:**"""

        if podcast_data.get('audio'):
            summary += f"\n• Audio podcast created: {podcast_data['audio']}"
        if podcast_data.get('script'):
            summary += f"\n• Script file generated: {podcast_data['script']}"

        summary += """
    
    💬 **What You Can Do Now:**
    - Browse and discuss any of the research articles below
    - Ask about weekly trends and patterns
    - Download your generated podcast files
    - Request follow-up analysis on specific topics
    
    📋 **Your Complete Research Results:**"""

        return summary

    def _needs_morning_greeting(self) -> bool:
        """Check if we should show morning greeting - simple daily flag"""
        today = datetime.now().strftime('%Y-%m-%d')
        flag_file = os.path.join(DATA_DIRECTORY, f'morning_greeting_{today}.flag')
        return not os.path.exists(flag_file)

    def _show_morning_greeting(self, session: ResearchAgentSession) -> Dict:
        """Show morning greeting with interests review"""
        try:
            # Load current interests using existing logic
            conn = sqlite3.connect(self.content_curator.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT interest, weight FROM user_interests ORDER BY weight DESC')
            interests = [dict(row) for row in cursor.fetchall()]
            conn.close()

            # Format interests display (reuse existing format from _show_interests)
            if interests:
                interests_list = []
                for interest in interests:
                    weight_bar = "🟦" * min(int(interest['weight']), 10)
                    interests_list.append(
                        f"• **{interest['interest']}** (Weight: {interest['weight']:.1f}) {weight_bar}")
                interests_text = "\n".join(interests_list)
            else:
                interests_text = "• No interests configured yet"

            greeting = f"""☀️ **Good Morning!**

    📋 **Your Current Research Interests:**
    {interests_text}

    🤔 **Before I begin today's analysis, do you want to change any of your interests?**

    - Say **"yes"** to adjust interests  
    - Say **"no"** to start research immediately"""

            return {
                'response': greeting,
                'actions': [],
                'state': 'morning_greeting'
            }
        except Exception as e:
            print(f"Error showing morning greeting: {e}")
            # Fallback: proceed with normal workflow
            self._mark_morning_greeting_shown()
            session.update_state("initialization")
            return self._check_hot_topics(session)

    def _handle_morning_greeting_response(self, session: ResearchAgentSession, message: str) -> Dict:
        """Handle yes/no response to morning greeting"""
        message_lower = message.lower().strip()

        if message_lower in ['yes', 'y', 'adjust', 'modify', 'change']:
            session.update_state("morning_interests")
            session.context['in_morning_flow'] = True
            return {
                'response': "📋 **Adjust Your Interests**\n\nYou can:\n• \"Add [topic] with weight [1-10]\"\n• \"Remove [topic] interest\"\n• \"Change weight of [topic] to [number]\"\n• \"Show my interests\"\n\n**When finished, say 'done' to start today's analysis.**",
                'actions': [],
                'state': 'morning_interests'
            }
        elif message_lower in ['no', 'n', 'start', 'begin', 'proceed']:
            self._mark_morning_greeting_shown()

            if session.context.get('pending_chain_workflow'):
                chain_steps = ['collection', 'week_review', 'podcast']
                session.enable_chain_workflow(chain_steps)
                print(f"🔗 Chain workflow enabled after morning greeting: {' → '.join(chain_steps)}")

            # Continue with original hot topics workflow
            session.update_state("initialization")
            return self._check_hot_topics(session)
        else:
            return {
                'response': "🤔 Please say **'yes'** to adjust interests or **'no'** to start analysis.",
                'actions': [],
                'state': 'morning_greeting'
            }

    def _handle_morning_interests_response(self, session: ResearchAgentSession, message: str) -> Dict:
        """Handle interests adjustment during morning routine"""
        message_lower = message.lower().strip()

        if message_lower in ['done', 'finished', 'complete', 'start', 'begin']:
            self._mark_morning_greeting_shown()
            session.context.pop('in_morning_flow', None)

            if session.context.get('pending_chain_workflow'):
                chain_steps = ['collection', 'week_review', 'podcast']
                session.enable_chain_workflow(chain_steps)
                print(f"🔗 Chain workflow enabled after interests adjustment: {' → '.join(chain_steps)}")

            # Return to hot topics workflow
            session.update_state("initialization")
            return self._check_hot_topics(session)
        else:
            # Use existing interests command handler
            result = self._handle_interests_command(session, message)
            # Keep in morning_interests state instead of going to confirmation
            if result.get('state') == 'interests_confirmation':
                result['state'] = 'morning_interests_confirmation'
            return result

    def _handle_morning_interests_confirmation(self, session: ResearchAgentSession, message: str) -> Dict:
        """Handle confirmation during morning interests adjustment"""
        message_lower = message.lower().strip()

        if message_lower in ['yes', 'y', 'confirm', 'ok', 'proceed']:
            # Execute the pending action using existing logic
            pending = session.context.get('pending_interests_action')
            if not pending:
                session.update_state('morning_interests')
                return {
                    'response': "❌ **No pending action**\n\nPlease make a new interests request or say 'done' to continue.",
                    'actions': [],
                    'state': 'morning_interests'
                }

            result = self._execute_interests_action(session, pending)
            # Override state to keep in morning flow
            result['state'] = 'morning_interests'
            result['response'] += "\n\n**Say 'done' when finished or continue adjusting interests.**"
            return result

        elif message_lower in ['no', 'n', 'cancel', 'abort']:
            # Cancel the action and return to morning interests
            session.context.pop('pending_interests_action', None)
            session.update_state('morning_interests')
            return {
                'response': "✅ **Action cancelled**\n\nContinue adjusting interests or say 'done' to start analysis.",
                'actions': [],
                'state': 'morning_interests'
            }
        else:
            return {
                'response': "🤔 **Please confirm**\n\nSay 'yes' to proceed or 'no' to cancel the interests action.",
                'actions': [],
                'state': 'morning_interests_confirmation'
            }

    def _mark_morning_greeting_shown(self):
            """Mark that morning greeting has been shown today"""
            try:
                today = datetime.now().strftime('%Y-%m-%d')
                flag_file = os.path.join(DATA_DIRECTORY, f'morning_greeting_{today}.flag')
                print(f"🔍 DEBUG: Attempting to create flag file: {flag_file}")
                print(f"🔍 DEBUG: DATA_DIRECTORY exists: {os.path.exists(DATA_DIRECTORY)}")

                with open(flag_file, 'w') as f:
                    f.write(str(datetime.now().timestamp()))

                print(f"✅ Marked morning greeting as shown for {today}")
                print(f"🔍 DEBUG: Flag file exists after creation: {os.path.exists(flag_file)}")

            except Exception as e:
                print(f"❌ ERROR: Could not create morning greeting flag: {e}")
                import traceback
                traceback.print_exc()