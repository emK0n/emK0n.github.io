import sqlite3
import json
import os
import threading
import time
import uuid
import subprocess
import tempfile
import shutil
from datetime import datetime, timedelta
import logging
from pathlib import Path
from typing import List, Dict, Optional, Any, Tuple
from current_events import trigger_analysis_for_podcast, get_current_events_status

# New dependencies for edge-tts implementation
try:
    from pydub import AudioSegment
    from pydub.silence import split_on_silence
    PYDUB_AVAILABLE = True
except ImportError:
    PYDUB_AVAILABLE = False
    print("⚠️ pydub not available. Install with: pip install pydub")


class PodcastSession:
    """Session management for podcast generation"""
    def __init__(self, session_id):
        self.session_id = session_id
        self.status = 'initializing'
        self.progress = {}
        self.context = {}
        self.created_at = datetime.now()
        self.completed = False
        self.error = None
        self.files_generated = {}


class DialoguePiece:
    """Represents a single piece of dialogue with speaker and text"""
    def __init__(self, speaker, text, sequence_order):
        self.speaker = speaker
        self.text = text.strip()
        self.sequence_order = sequence_order
        self.audio_file = None
        self.duration = 0.0
    
    def __repr__(self):
        return f"DialoguePiece(speaker='{self.speaker}', order={self.sequence_order}, text='{self.text[:50]}...')"


class PodcastGenerator:
    """Daily Podcast Generator - Creates audio podcasts from top articles with Edge-TTS"""
    
    # Voice configuration for Edge-TTS
    VOICE_CONFIG = {
        'Alex': 'en-US-AriaNeural',      # Female voice for Alex
        'Sam': 'en-US-ChristopherNeural'  # Male voice for Sam
    }
    
    # Audio settings
    SPEAKER_PAUSE_DURATION = 0.8  # Seconds between different speakers
    SENTENCE_PAUSE_DURATION = 0.3  # Seconds between sentences from same speaker
    
    def __init__(self, curator, chat_assistant):
        self.curator = curator
        self.chat_assistant = chat_assistant
        self.sessions = {}
        self.data_directory = "data"
        os.makedirs(self.data_directory, exist_ok=True)
        
        # Check for edge-tts availability
        self.edge_tts_available = self._check_edge_tts_availability()
        if not self.edge_tts_available:
            print("⚠️ edge-tts not available. Install with: pip install edge-tts")
    
    def _check_edge_tts_availability(self):
        """Check if edge-tts is available"""
        try:
            result = subprocess.run(['edge-tts', '--list-voices'], 
                                  capture_output=True, text=True, timeout=10)
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError, subprocess.SubprocessError):
            return False
    
    def start_podcast_generation(self, session_id, chain_context: bool = False):
        """Start the podcast generation workflow"""
        try:
            # Create new session
            session = PodcastSession(session_id)
            session.chain_context = chain_context  # NEW: Store chain context
            self.sessions[session_id] = session
            
            # Start generation in background thread
            generation_thread = threading.Thread(
                target=self._run_podcast_generation,
                args=(session,),
                daemon=True
            )
            generation_thread.start()
            
            return {
                'status': 'started',
                'message': 'Daily podcast generation started',
                'session_id': session_id,
                'edge_tts_enabled': self.edge_tts_available
            }
            
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Failed to start podcast generation: {str(e)}'
            }
    
    def _run_podcast_generation(self, session):
        """Main podcast generation workflow"""
        try:
            session.status = 'running'
            print(f"🎙️ Starting podcast generation for session {session.session_id}")
            self._update_progress(session, 'Starting daily podcast generation...', 0)

            # Step A: Hot Topics Check and Research Workflow
            print("🔍 Step A: Checking for current events analysis...")
            self._update_progress(session, 'Checking for current events analysis...', 10)
            self._check_and_handle_hot_topics(session)

            # Step B: Content Selection
            self._update_progress(session, 'Selecting top 5 articles for podcast...', 40)
            articles = self._select_top_articles()
            
            if len(articles) < 3:
                raise Exception(f"Insufficient articles found for podcast (found {len(articles)}, need at least 3)")
            
            session.context['selected_articles'] = articles
            self._update_progress(session, f'Selected {len(articles)} articles for discussion', 50)
            
            # Step C: Script Generation
            self._update_progress(session, 'Generating podcast script with Alex and Sam...', 60)
            script = self._generate_podcast_script(articles)
            
            # Save script file
            today = datetime.now().strftime("%Y%m%d")
            script_filename = f"podcast_{today}.txt"
            script_path = os.path.join(self.data_directory, script_filename)
            
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(script)
            
            session.files_generated['script'] = script_filename
            self._update_progress(session, f'Script generated and saved as {script_filename}', 70)
            
            # Step D: Audio Conversion with Edge-TTS
            self._update_progress(session, 'Converting script to audio with distinct voices...', 80)
            audio_filename = self._convert_to_audio_enhanced(script, today, session)
            
            session.files_generated['audio'] = audio_filename
            self._update_progress(session, f'Audio generated and saved as {audio_filename}', 100)
            
            # Mark as completed
            session.status = 'completed'
            session.completed = True
            
            self._update_progress(session, 'Daily podcast generation completed successfully!', 100)

            # NEW: Store podcast data in research session if chain context
            if getattr(session, 'chain_context', False):
                self._store_podcast_in_research_session(session.session_id, session.files_generated)

        except Exception as e:
            print(f"❌ Podcast generation error: {str(e)}")
            import traceback
            traceback.print_exc()
            session.status = 'error'
            session.error = str(e)
            self._update_progress(session, f'Error during podcast generation: {str(e)}', 0)

    def _store_podcast_in_research_session(self, session_id: str, podcast_files: Dict):
        """Store podcast files data in research agent session for chain workflows"""
        try:
            # Import here to avoid circular imports
            from app import research_assistant

            if session_id in research_assistant.sessions:
                session = research_assistant.sessions[session_id]
                session.context['podcast_files'] = podcast_files
                print(f"🔗 Stored podcast data in research session {session_id}")
        except Exception as e:
            print(f"Warning: Could not store podcast data in research session: {e}")

    # ===============================
    # PHASE 1: SCRIPT PARSING
    # ===============================
    
    def _parse_script_by_speaker(self, script):
        """Parse script text to identify speaker lines and create dialogue sequence"""
        dialogue_pieces = []
        sequence_order = 0
        
        lines = script.split('\n')
        current_speaker = None
        current_text = ""
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Check if line starts with speaker label
            if line.startswith('Alex:') or line.startswith('Sam:'):
                # Save previous dialogue piece if exists
                if current_speaker and current_text:
                    dialogue_pieces.append(DialoguePiece(current_speaker, current_text, sequence_order))
                    sequence_order += 1
                
                # Start new dialogue piece
                if line.startswith('Alex:'):
                    current_speaker = 'Alex'
                    current_text = line[5:].strip()  # Remove "Alex:" prefix
                elif line.startswith('Sam:'):
                    current_speaker = 'Sam'
                    current_text = line[4:].strip()  # Remove "Sam:" prefix
            
            elif current_speaker:
                # Continue previous speaker's dialogue
                current_text += " " + line
            
            else:
                # Non-dialogue text (intro, transitions) - assign to narrator (Alex by default)
                if line and not line.startswith('---'):  # Skip separator lines
                    dialogue_pieces.append(DialoguePiece('Alex', line, sequence_order))
                    sequence_order += 1
        
        # Don't forget the last piece
        if current_speaker and current_text:
            dialogue_pieces.append(DialoguePiece(current_speaker, current_text, sequence_order))
        
        print(f"📝 Parsed script into {len(dialogue_pieces)} dialogue pieces")
        for i, piece in enumerate(dialogue_pieces[:3]):  # Show first 3 for debugging
            print(f"   {i+1}. {piece.speaker}: {piece.text[:60]}...")
        
        return dialogue_pieces
    
    # ===============================
    # PHASE 2: EDGE-TTS INTEGRATION
    # ===============================
    
    def _generate_speaker_audio(self, text, voice, output_path, session=None):
        """Generate audio using edge-tts for a specific speaker"""
        try:
            if not self.edge_tts_available:
                raise Exception("edge-tts not available")
            
            # Clean text for TTS
            clean_text = self._clean_text_for_tts(text)
            if not clean_text.strip():
                return False
            
            # Prepare edge-tts command
            cmd = [
                'edge-tts',
                '--voice', voice,
                '--text', clean_text,
                '--write-media', output_path,
                '--write-subtitles', output_path.replace('.mp3', '.vtt')
            ]
            
            # Execute edge-tts with timeout
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,  # 30 second timeout per clip
                cwd=self.data_directory
            )
            
            if result.returncode != 0:
                print(f"❌ edge-tts failed: {result.stderr}")
                return False
            
            # Verify file was created and has content
            if os.path.exists(output_path):
                file_size = os.path.getsize(output_path)
                if file_size > 1000:  # At least 1KB
                    print(f"✅ Generated audio: {os.path.basename(output_path)} ({file_size} bytes)")
                    return True
                else:
                    print(f"⚠️ Generated audio file too small: {file_size} bytes")
                    return False
            else:
                print(f"❌ Audio file not created: {output_path}")
                return False
                
        except subprocess.TimeoutExpired:
            print(f"❌ edge-tts timed out for voice {voice}")
            return False
        except Exception as e:
            print(f"❌ Error generating audio with edge-tts: {e}")
            return False
    
    def _clean_text_for_tts(self, text):
        """Clean text to make it suitable for TTS"""
        import re
        
        # Remove markdown formatting
        text = re.sub(r'\*\*([^*]+)\*\*', r'\1', text)  # Bold
        text = re.sub(r'\*([^*]+)\*', r'\1', text)      # Italic
        text = re.sub(r'`([^`]+)`', r'\1', text)        # Code
        
        # Remove URLs
        text = re.sub(r'https?://[^\s]+', '', text)
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Ensure proper sentence endings
        text = text.strip()
        if text and not text.endswith(('.', '!', '?')):
            text += '.'
        
        return text
    
    # ===============================
    # PHASE 3: AUDIO ASSEMBLY
    # ===============================
    
    def _combine_audio_clips(self, dialogue_pieces, final_path, session=None):
        """Combine individual audio clips into final podcast"""
        if not PYDUB_AVAILABLE:
            raise Exception("pydub not available for audio assembly")
        
        try:
            print(f"🎵 Combining {len(dialogue_pieces)} audio clips...")
            
            # Create final audio sequence
            final_audio = AudioSegment.empty()
            last_speaker = None
            
            for i, piece in enumerate(dialogue_pieces):
                if not piece.audio_file or not os.path.exists(piece.audio_file):
                    print(f"⚠️ Skipping missing audio file for piece {i+1}")
                    continue
                
                try:
                    # Load audio clip
                    audio_clip = AudioSegment.from_mp3(piece.audio_file)
                    
                    # Add pause if speaker changed
                    if last_speaker and last_speaker != piece.speaker:
                        pause = AudioSegment.silent(duration=int(self.SPEAKER_PAUSE_DURATION * 1000))
                        final_audio += pause
                        print(f"   Added {self.SPEAKER_PAUSE_DURATION}s pause (speaker change)")
                    elif last_speaker == piece.speaker:
                        # Same speaker, shorter pause
                        pause = AudioSegment.silent(duration=int(self.SENTENCE_PAUSE_DURATION * 1000))
                        final_audio += pause
                    
                    # Add the actual audio
                    final_audio += audio_clip
                    last_speaker = piece.speaker
                    
                    # Update progress
                    if session:
                        progress = 85 + (10 * (i + 1) / len(dialogue_pieces))
                        self._update_progress(session, f'Combining audio: {i+1}/{len(dialogue_pieces)}', progress)
                    
                    print(f"   Added clip {i+1}: {piece.speaker} ({len(audio_clip)/1000:.1f}s)")
                    
                except Exception as e:
                    print(f"❌ Error loading audio clip {i+1}: {e}")
                    continue
            
            if len(final_audio) == 0:
                raise Exception("No audio clips could be combined")
            
            # Export final audio
            print(f"💾 Exporting final audio to {final_path}...")
            final_audio.export(final_path, format="wav")
            
            # Verify final file
            if os.path.exists(final_path):
                file_size = os.path.getsize(final_path)
                duration = len(final_audio) / 1000.0
                print(f"✅ Final podcast: {os.path.basename(final_path)} ({file_size} bytes, {duration:.1f}s)")
                return True
            else:
                raise Exception("Final audio file was not created")
                
        except Exception as e:
            print(f"❌ Error combining audio clips: {e}")
            raise
    
    # ===============================
    # PHASE 4: ERROR HANDLING & CLEANUP
    # ===============================
    
    def _cleanup_temp_files(self, temp_dir):
        """Clean up temporary audio files"""
        try:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
                print(f"🧹 Cleaned up temporary directory: {temp_dir}")
        except Exception as e:
            print(f"⚠️ Error cleaning up temp files: {e}")
    
    def _convert_to_audio_enhanced(self, script, date_str, session):
        """Enhanced audio conversion using Edge-TTS with distinct voices"""
        temp_dir = None
        
        try:
            print(f"🎤 Starting enhanced audio conversion for {date_str}")
            
            # Phase 1: Parse script by speaker
            self._update_progress(session, 'Parsing script by speaker...', 75)
            dialogue_pieces = self._parse_script_by_speaker(script)
            
            if not dialogue_pieces:
                raise Exception("No dialogue pieces found in script")
            
            # Check if we can use edge-tts
            if not self.edge_tts_available or not PYDUB_AVAILABLE:
                print("⚠️ Falling back to legacy TTS method")
                return self._convert_to_audio_legacy(script, date_str)
            
            # Create temporary directory for individual clips
            temp_dir = tempfile.mkdtemp(prefix=f"podcast_{date_str}_")
            print(f"📁 Using temporary directory: {temp_dir}")
            
            # Phase 2: Generate individual audio clips
            self._update_progress(session, 'Generating individual voice clips...', 78)
            successful_clips = 0
            
            for i, piece in enumerate(dialogue_pieces):
                voice = self.VOICE_CONFIG.get(piece.speaker, self.VOICE_CONFIG['Alex'])
                clip_filename = f"clip_{i:03d}_{piece.speaker.lower()}.mp3"
                clip_path = os.path.join(temp_dir, clip_filename)
                
                # Generate audio for this piece
                if self._generate_speaker_audio(piece.text, voice, clip_path, session):
                    piece.audio_file = clip_path
                    successful_clips += 1
                else:
                    print(f"❌ Failed to generate audio for piece {i+1}")
                
                # Update progress
                progress = 78 + (7 * (i + 1) / len(dialogue_pieces))
                self._update_progress(session, f'Generated voice clip {i+1}/{len(dialogue_pieces)}', progress)
            
            if successful_clips == 0:
                raise Exception("No audio clips were successfully generated")
            
            print(f"✅ Successfully generated {successful_clips}/{len(dialogue_pieces)} audio clips")
            
            # Phase 3: Combine audio clips
            self._update_progress(session, 'Combining audio clips into final podcast...', 85)
            
            audio_filename = f"podcast_{date_str}.mp3"
            final_audio_path = os.path.join(self.data_directory, audio_filename)
            
            self._combine_audio_clips(dialogue_pieces, final_audio_path, session)
            
            # Phase 4: Cleanup
            self._cleanup_temp_files(temp_dir)
            
            return audio_filename
            
        except Exception as e:
            print(f"❌ Enhanced audio conversion failed: {e}")
            
            # Cleanup on error
            if temp_dir:
                self._cleanup_temp_files(temp_dir)
            
            # Try legacy fallback
            try:
                print("🔄 Attempting legacy TTS fallback...")
                return self._convert_to_audio_legacy(script, date_str)
            except Exception as fallback_error:
                print(f"❌ Legacy fallback also failed: {fallback_error}")
                
                # Create error log as final fallback
                return self._create_error_fallback(script, date_str, str(e))
    
    def _convert_to_audio_legacy(self, script, date_str):
        """Legacy audio conversion method (simplified pyttsx3 fallback)"""
        try:
            print("🎤 Using legacy TTS method...")
            
            # Try to use system TTS if available
            import subprocess
            import platform
            
            audio_filename = f"podcast_{date_str}.mp3"
            audio_path = os.path.join(self.data_directory, audio_filename)
            
            # Clean script for audio generation
            clean_script = self._extract_clean_text(script)
            
            if platform.system() == "Darwin":  # macOS
                print("🍎 Using macOS system TTS...")
                
                temp_script_path = os.path.join(self.data_directory, f"temp_script_{date_str}.txt")
                with open(temp_script_path, 'w', encoding='utf-8') as f:
                    f.write(clean_script)
                
                result = subprocess.run([
                    'say',
                    '-f', temp_script_path,
                    '-o', audio_path.replace('.mp3', '.aiff'),
                    '--data-format=LEF32@22050'
                ], capture_output=True, text=True, timeout=120)
                
                if result.returncode == 0:
                    # Convert AIFF to MP3
                    aiff_path = audio_path.replace('.mp3', '.aiff')
                    subprocess.run(['ffmpeg', '-i', aiff_path, audio_path], check=True)
                    os.remove(aiff_path)  # Clean up AIFF file
                    os.remove(temp_script_path)
                    return os.path.basename(audio_path)
            
            # If system TTS fails, create script file
            raise Exception("System TTS not available")
            
        except Exception as e:
            print(f"❌ Legacy TTS failed: {e}")
            return self._create_error_fallback(script, date_str, str(e))
    
    def _extract_clean_text(self, script):
        """Extract clean text from script for legacy TTS"""
        clean_text = ""
        for line in script.split('\n'):
            line = line.strip()
            if line:
                if line.startswith('Alex:') or line.startswith('Sam:'):
                    dialogue = line.split(':', 1)[1].strip()
                    if dialogue:
                        clean_text += dialogue + " "
                else:
                    clean_text += line.strip() + " "
        return clean_text
    
    def _create_error_fallback(self, script, date_str, error_msg):
        """Create enhanced script file as final fallback"""
        fallback_filename = f"podcast_{date_str}_script.txt"
        fallback_path = os.path.join(self.data_directory, fallback_filename)
        
        with open(fallback_path, 'w', encoding='utf-8') as f:
            f.write(f"DAILY PODCAST SCRIPT - {date_str}\n")
            f.write("=" * 60 + "\n\n")
            f.write("AUDIO GENERATION FAILED - SCRIPT ONLY\n")
            f.write(f"Error: {error_msg}\n\n")
            f.write("To create audio manually:\n")
            f.write("1. Install edge-tts: pip install edge-tts pydub\n")
            f.write("2. Copy the script below\n")
            f.write("3. Use text-to-speech software of your choice\n\n")
            f.write("VOICE ASSIGNMENTS:\n")
            f.write("- Alex (female): en-US-AriaNeural\n")
            f.write("- Sam (male): en-US-ChristopherNeural\n\n")
            f.write("SCRIPT:\n")
            f.write("-" * 40 + "\n\n")
            f.write(script)
            f.write(f"\n\n--- Generated at {datetime.now().isoformat()} ---")
        
        print(f"📄 Enhanced script file created: {fallback_filename}")
        return fallback_filename
    
    # ===============================
    # EXISTING METHODS (PRESERVED)
    # ===============================
    
    def _check_and_handle_hot_topics(self, session):
        """Check for hot topics and run research workflow if needed"""
        hot_topics_keywords = self._get_hot_topics_keywords()

        if hot_topics_keywords:
            print(f"✅ Found existing hot topics: {hot_topics_keywords}")
            self._update_progress(session, 'Using existing hot topics analysis...', 30)
            return True
        else:
            print("❌ No current hot topics found, running full research workflow...")
            self._update_progress(session, 'No current events analysis found. Running research workflow...', 15)

            success = self._run_research_agent_workflow(session)
            if not success:
                raise Exception("Research agent workflow failed")

            self._update_progress(session, 'Research workflow completed. Proceeding with podcast...', 40)
            return True
    
    def _get_hot_topics_keywords(self):
        """Get hot topics keywords from today's analysis"""
        try:
            import glob
            
            today = datetime.now().strftime("%Y%m%d")
            files = glob.glob(os.path.join(self.data_directory, f"current_events_analysis_{today}.json"))
            
            if not files:
                return []
            
            latest_file = max(files, key=os.path.getctime)
            with open(latest_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            analysis = data.get('analysis', {})
            return analysis.get('search_keywords', [])[:15]
            
        except Exception as e:
            print(f"Error getting hot topics keywords: {e}")
            return []
    
    def _select_top_articles(self):
        """Select top 5 articles based on relevance_score + relevance_boost"""
        try:
            conn = sqlite3.connect(self.curator.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            since_date = (datetime.now() - timedelta(hours=48)).isoformat()
            
            cursor.execute('''
                SELECT *, 
                       (relevance_score + COALESCE(relevance_boost, 0)) as total_relevance,
                       COALESCE(relevance_boost, 0) as boost_score
                FROM content 
                WHERE added_date > ?
                AND content IS NOT NULL
                AND content != ''
                ORDER BY total_relevance DESC, relevance_score DESC, published_date DESC 
                LIMIT 5
            ''', (since_date,))
            
            articles = [dict(row) for row in cursor.fetchall()]
            conn.close()
            
            return articles
            
        except Exception as e:
            raise Exception(f"Failed to select articles: {str(e)}")
    
    def _generate_podcast_script(self, articles):
        """Generate 2000-2500 word podcast script with Alex and Sam personas"""
        try:
            articles_summary = ""
            for i, article in enumerate(articles, 1):
                articles_summary += f"\nArticle {i}: {article['title']}\n"
                articles_summary += f"Source: {article['source']}\n"
                articles_summary += f"Summary: {article.get('ai_summary', 'No summary available')}\n"
                articles_summary += f"Relevance Score: {article.get('total_relevance', article['relevance_score']):.1f}\n"
                articles_summary += "---\n"

            prompt = f"""Generate a natural, engaging podcast script between two hosts named Alex and Sam discussing today's top news stories. The script must be 2000-2500 words total.

            ARTICLES TO DISCUSS:
            {articles_summary}

            SCRIPT STRUCTURE & LENGTH REQUIREMENTS:
            - Brief intro with banter: 100-150 words
            - Article discussions: 1800-2200 words (spend 200-300 words per major article)
            - Conclusion: 150-200 words
            - CRITICAL: Do not summarize articles superficially. Dive deep into implications, context, and analysis.

            HOST PERSONALITIES:
            - Alex (female): Enthusiastic technophile who loves minute details, random facts, and deep analytical dives into the "why" behind stories
            - Sam (male): Reserved, conservative, business-focused. Prefers examining practical implications, market impacts, and real-world relevance

            DEPTH REQUIREMENTS FOR EACH ARTICLE:
            - Don't just report what happened - explore WHY it matters
            - Include background context listeners might not know
            - Analyze potential consequences and future implications
            - Connect stories to broader trends or ongoing themes
            - Alex should dig into technical details, data points, and interesting connections
            - Sam should focus on business implications, practical effects, and skeptical questions
            - Include natural disagreements where they have different perspectives

            CONVERSATION FLOW:
            - Spend substantial time on each article - don't rush through
            - Include smooth transitions between topics
            - Let discussions breathe and develop naturally
            - Alex tends to go deeper analytically, Sam pulls back to practical relevance
            - Include agreements, disagreements, and natural back-and-forth
            
            This script should be roughly the length of a 15-20 minute podcast episode when read aloud. Make sure again that each topic has 300 words minimum.

            FORMAT:
            Alex: [dialogue]
            Sam: [dialogue]

            Begin the script now:"""

            script = self.chat_assistant.generate_response(prompt)
            
            if len(script) < 800:
                extend_prompt = f"The podcast script is too short. Please extend this script to reach 2000-2500 words while maintaining quality:\n\n{script}\n\nContinue the conversation:"
                extension = self.chat_assistant.generate_response(extend_prompt)
                script += "\n\n" + extension
            
            return script
            
        except Exception as e:
            raise Exception(f"Failed to generate script: {str(e)}")
    
    def _run_research_agent_workflow(self, session):
        """Run the research agent initialization workflow for podcast"""
        try:
            temp_session_id = f"podcast_{session.session_id}"

            self._update_progress(session, 'Starting hot topics analysis...', 20)
            self._trigger_hot_topics_analysis()
            self._wait_for_hot_topics_with_progress(session, 20, 35)

            self._update_progress(session, 'Running article collection with hot topics boost...', 35)

            hot_topics_keywords = self._get_hot_topics_keywords()
            if hot_topics_keywords:
                stats = self.curator.run_collection_cycle(
                    max_process=20,
                    time_range_hours=48,
                    hot_topics_keywords=hot_topics_keywords
                )

                self._wait_for_collection_with_progress(session, 35, 40)

                rescore_stats = self.curator.rescore_with_hot_topics(hot_topics_keywords)
                session.context['rescore_stats'] = rescore_stats
                session.context['collection_stats'] = stats

                return True
            else:
                print("⚠️ Hot topics analysis completed but no keywords found")
                return False

        except Exception as e:
            print(f"❌ Research workflow error: {e}")
            return False
    
    def _trigger_hot_topics_analysis(self):
        """Trigger hot topics analysis if needed"""
        trigger_analysis_for_podcast()

    def _wait_for_hot_topics_with_progress(self, session, start_progress, end_progress):
        """Wait for hot topics with progress updates"""
        max_wait_time = 300
        start_time = time.time()

        while True:
            if time.time() - start_time > max_wait_time:
                raise Exception("Hot topics analysis timed out")

            status = get_current_events_status()
            elapsed_ratio = min((time.time() - start_time) / max_wait_time, 1.0)
            current_progress = start_progress + (end_progress - start_progress) * elapsed_ratio

            if status['completed']:
                if not status['success']:
                    error_msg = status['error'] or "Hot topics analysis failed"
                    raise Exception(f"Hot topics analysis failed: {error_msg}")
                break

            message = f"Hot topics analysis: {status['status']}"
            self._update_progress(session, message, current_progress)
            time.sleep(3)

        self._update_progress(session, "Hot topics analysis completed", end_progress)

    def _wait_for_collection_with_progress(self, session, start_progress, end_progress):
        """Wait for collection with progress updates"""
        max_wait_time = 600
        start_time = time.time()

        while True:
            if time.time() - start_time > max_wait_time:
                raise Exception("Collection cycle timed out")

            progress = self.curator.get_operation_progress()

            if progress['status'] == 'idle':
                break

            elapsed_ratio = min((time.time() - start_time) / max_wait_time, 1.0)
            current_progress = start_progress + (end_progress - start_progress) * elapsed_ratio

            message = progress.get('current_message', 'Processing articles...')
            if progress.get('total', 0) > 0:
                completed = progress.get('completed', 0)
                total = progress.get('total', 0)
                message += f" ({completed}/{total})"

            self._update_progress(session, f"Collection: {message}", current_progress)
            time.sleep(2)

        self._update_progress(session, "Article collection completed", end_progress)
    
    def _update_progress(self, session, message, percentage):
        """Update session progress with verbose status message"""
        session.progress = {
            'status': session.status,
            'message': message,
            'percentage': percentage,
            'timestamp': datetime.now().isoformat(),
            'completed': session.completed,
            'error': session.error,
            'files_generated': session.files_generated
        }
    
    def get_progress(self, session_id):
        """Get current progress for a podcast generation session"""
        session = self.sessions.get(session_id)
        if not session:
            return None
        
        return {
            'session_id': session_id,
            'status': session.status,
            'progress': session.progress,
            'completed': session.completed,
            'error': session.error,
            'files_generated': session.files_generated,
            'context': {
                'articles_count': len(session.context.get('selected_articles', [])),
                'collection_run': 'collection_stats' in session.context,
                'rescore_applied': 'rescore_stats' in session.context
            }
        }

    def cleanup_old_sessions(self, max_age_hours=24):
        """Clean up old podcast sessions"""
        cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
        
        sessions_to_remove = []
        for session_id, session in self.sessions.items():
            if session.created_at < cutoff_time:
                sessions_to_remove.append(session_id)
        
        for session_id in sessions_to_remove:
            del self.sessions[session_id]
        
        return len(sessions_to_remove)