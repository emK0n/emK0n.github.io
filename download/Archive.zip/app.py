from flask import Flask, render_template, jsonify, request, session
import sqlite3
from datetime import datetime, timedelta
import os
import threading
import json
import glob
import uuid
import time
import hashlib
from content_curator import ContentCurator, ChatAssistant
from research_agent import ResearchAssistant
from current_events import current_events_bp, set_data_directory
from week_review_integration import initialize_week_review, add_week_review_endpoints, enhance_research_agent_with_week_review
from podcast_generator import PodcastGenerator

# Define DATA_DIR and create directory first
DATA_DIR = os.environ.get('DATA_DIR', 'data')
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs('templates', exist_ok=True)

# Initialize core components
curator = ContentCurator(
    db_path=os.path.join(DATA_DIR, "content_curator.db"),
    config_file=os.path.join(DATA_DIR, "sources_config.json")
)

#Init PDF Support
try:
    from pdf_parser import PDFProcessor, is_pdf_url, get_pdf_capabilities, process_pdf
    HAS_PDF_SUPPORT = True
except ImportError:
    HAS_PDF_SUPPORT = False

# Flask Web Interface
app = Flask(__name__, static_folder='static', static_url_path='/static')
app.secret_key = os.environ.get('SECRET_KEY', 'your-secret-key-here')

# Initialize components in correct order
chat_assistant = ChatAssistant(os.path.join(DATA_DIR, "content_curator.db"), curator.ollama_model)
research_assistant = ResearchAssistant(curator, chat_assistant)  # Enhanced Research Assistant
podcast_generator = PodcastGenerator(curator, chat_assistant)  # Enhanced with Edge-TTS
week_review_processor = initialize_week_review(chat_assistant, data_directory=DATA_DIR)

# Register blueprints and configure
app.register_blueprint(current_events_bp)
set_data_directory(DATA_DIR)
add_week_review_endpoints(app)
research_assistant = enhance_research_agent_with_week_review(research_assistant)

def check_dependencies_status():
    """Check status of optional dependencies for enhanced features"""
    status = {
        'edge_tts': False,
        'pydub': False,
        'system_tts': False
    }
    
    # Check edge-tts
    try:
        import subprocess
        result = subprocess.run(['edge-tts', '--list-voices'], 
                              capture_output=True, text=True, timeout=5)
        status['edge_tts'] = result.returncode == 0
    except:
        pass
    
    # Check pydub
    try:
        from pydub import AudioSegment
        status['pydub'] = True
    except ImportError:
        pass
    
    # Check system TTS
    import platform
    if platform.system() == "Darwin":
        try:
            result = subprocess.run(['which', 'say'], capture_output=True)
            status['system_tts'] = result.returncode == 0
        except:
            pass
    elif platform.system() == "Linux":
        try:
            result = subprocess.run(['which', 'espeak'], capture_output=True)
            status['system_tts'] = result.returncode == 0
        except:
            pass
    
    return status

@app.route('/')
def index():
    template_path = os.path.join('templates', 'index.html')
    if not os.path.exists(template_path):
        # Create the research agent template from our HTML artifact
        with open(template_path, 'w', encoding='utf-8') as template_file:
            template_file.write("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Research Assistant Agent</title>
    <!-- Include the enhanced HTML with search capabilities -->
</head>
<body>
    <!-- Copy the body content from the enhanced frontend artifact -->
</body>
</html>""")
    return render_template('index.html')

@app.route('/arch')
def new_page():
    return render_template('arch.html')

# ===============================
# ENHANCED RESEARCH AGENT ENDPOINTS
# ===============================

@app.route('/api/research-agent/start', methods=['POST'])
def start_research_session():
    """Start a new research assistant session"""
    try:
        data = request.json
        session_id = data.get('session_id')
        auto_start = data.get('auto_start_workflow', False)
        chain_workflow = data.get('chain_workflow', False)          # ADD THIS
        skip_morning_greeting = data.get('skip_morning_greeting', False)
        force_refresh = data.get('force_refresh', False)

        print(f"🔍 DEBUG Extracted parameters:")
        print(f"   auto_start: {auto_start}")
        print(f"   chain_workflow: {chain_workflow}")
        print(f"   skip_morning_greeting: {skip_morning_greeting}")
        print(f"   force_refresh: {force_refresh}")

        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400

        result = research_assistant.start_session(
            session_id,
            auto_start_workflow=auto_start,
            chain_workflow=chain_workflow,
            skip_morning_greeting=skip_morning_greeting,
            force_refresh=force_refresh
        )

        return jsonify({
            'success': True,
            'session_id': session_id,
            **result
        })

    except Exception as e:
        return jsonify({'error': f'Failed to start research session: {str(e)}'}), 500

@app.route('/api/research-agent/message', methods=['POST'])
def research_agent_message():
    """Process message in research agent workflow"""
    try:
        data = request.json
        session_id = data.get('session_id')
        message = data.get('message', '').strip()
        is_system = data.get('is_system', False)

        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400

        if not message and not is_system:
            return jsonify({'error': 'Message required'}), 400

        result = research_assistant.process_message(session_id, message)

        # Add debug info for new states
        if session_id in research_assistant.sessions:
            session = research_assistant.sessions[session_id]
            result['debug_info'] = {
                'session_state': session.state,
                'boost_check_performed': session.context.get('boost_check_performed', False),
                'has_existing_boost': session.context.get('existing_boost_status', {}).get('has_boost_scoring', False)
            }

        return jsonify({
            'success': True,
            'session_id': session_id,
            **result
        })

    except Exception as e:
        return jsonify({'error': f'Research agent error: {str(e)}'}), 500


@app.route('/api/research-agent/search', methods=['POST'])
def research_agent_search():
    """Perform internet search through research agent - simplified"""
    try:
        data = request.json
        session_id = data.get('session_id')
        query = data.get('query', '').strip()
        max_results = data.get('max_results', 10)

        print(f"🚀 Starting simplified search for session: {session_id}")

        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400

        if not query:
            return jsonify({'error': 'Search query required'}), 400

        # Ensure session exists
        if session_id not in research_assistant.sessions:
            print(f"🔄 Creating session: {session_id}")
            result = research_assistant.start_session(session_id)

        # Perform search directly - results come back immediately
        search_result = research_assistant.perform_internet_search(session_id, query, max_results)

        if 'error' in search_result:
            return jsonify({
                'status': 'error',
                'error': search_result['error']
            }), 500

        # Store results in session for the progress endpoint to find
        if session_id in research_assistant.sessions:
            session = research_assistant.sessions[session_id]
            session.context['search_complete'] = True
            session.context['search_result'] = search_result

        # Still return 'started' so frontend polls as expected
        return jsonify({
            'status': 'started',
            'message': f'Internet search completed for: "{query}"',
            'query': query
        })

    except Exception as e:
        print(f"❌ Search error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'status': 'error',
            'error': f'Search error: {str(e)}'
        }), 500


@app.route('/api/research-agent/search-progress/<session_id>')
def get_search_progress(session_id):
    """Get progress for internet search"""
    try:
        print(f"🔍 Looking for session: {session_id}")
        print(f"🔍 Available sessions: {list(research_assistant.sessions.keys())}")
        session = research_assistant.sessions.get(session_id)
        if not session:
            return jsonify({'error': 'Session not found'}), 404

        # ADD THIS DEBUGGING BLOCK
        print(f"🔍 Session context keys: {list(session.context.keys())}")
        print(f"🔍 Search complete status: {session.context.get('search_complete', False)}")
        if 'search_result' in session.context:
            result = session.context['search_result']
            print(f"🔍 Search result type: {type(result)}")
            print(f"🔍 Search result keys: {list(result.keys()) if isinstance(result, dict) else 'Not a dict'}")
        else:
            print("🔍 No search_result in context")

        # Check if search is complete
        if session.context.get('search_complete', False):
            if 'search_error' in session.context:
                return jsonify({
                    'session_id': session_id,
                    'completed': True,
                    'success': False,
                    'error': session.context['search_error']
                })
            else:
                result = session.context.get('search_result', {})
                return jsonify({
                    'session_id': session_id,
                    'completed': True,
                    'success': True,
                    'result': result
                })
        else:
            # Search still in progress
            return jsonify({
                'session_id': session_id,
                'completed': False,
                'status': 'searching'
            })

    except Exception as e:
        return jsonify({'error': f'Search progress error: {str(e)}'}), 500


@app.route('/api/research-agent/collection', methods=['POST'])
def start_research_collection():
    """Start collection process for research agent"""
    try:
        data = request.json
        session_id = data.get('session_id')
        timeframe_hours = data.get('timeframe_hours', 48)

        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400

        # Get session to access hot topics keywords
        session = research_assistant.sessions.get(session_id)
        hot_topics_keywords = None
        if session:
            hot_topics_keywords = session.context.get('hot_topics_keywords', [])

        # Start collection in background thread
        def run_collection():
            try:
                stats = curator.run_collection_cycle(
                    max_process=None,
                    time_range_hours=timeframe_hours,
                    hot_topics_keywords=hot_topics_keywords
                )

                # Apply hot topics rescoring if we have keywords
                if hot_topics_keywords:
                    rescore_stats = curator.rescore_with_hot_topics(hot_topics_keywords)
                    stats.update({
                        'rescore_stats': rescore_stats,
                        'operation_type': 'research_collection_with_boost'
                    })

                # Update session with results
                research_assistant.update_collection_stats(session_id, stats)

            except Exception as e:
                print(f"Collection error: {e}")
                # Still update session to indicate completion
                research_assistant.update_collection_stats(session_id, {
                    'error': str(e),
                    'operation_type': 'research_collection_error'
                })

        # Start collection thread
        collection_thread = threading.Thread(target=run_collection, daemon=True)
        collection_thread.start()

        return jsonify({
            'status': 'started',
            'message': 'Research collection started',
            'timeframe_hours': timeframe_hours
        })

    except Exception as e:
        return jsonify({'error': f'Collection start error: {str(e)}'}), 500


@app.route('/api/research-agent/progress/<session_id>')
def get_research_progress(session_id):
    """Get progress for research collection"""
    try:
        session = research_assistant.sessions.get(session_id)

        # NEW: If this is a forced refresh, use global curator progress
        if session and session.context.get('forced_refresh'):
            progress = curator.get_operation_progress()
            return jsonify({
                'session_id': session_id,
                'progress': progress,
                'forced_refresh': True
            })

        # Get current operation progress
        progress = curator.get_operation_progress()

        # Get session info if available
        session = research_assistant.sessions.get(session_id)
        session_info = {}
        if session:
            session_info = {
                'state': session.state,
                'context_keys': list(session.context.keys())
            }

        return jsonify({
            'session_id': session_id,
            'progress': progress,
            'session_info': session_info
        })

    except Exception as e:
        return jsonify({'error': f'Progress error: {str(e)}'}), 500


@app.route('/api/research-agent/articles/<session_id>')
def get_research_articles(session_id):
    """Get top articles for research session"""
    try:
        session = research_assistant.sessions.get(session_id)
        if not session:
            return jsonify({'error': 'Session not found'}), 404

        # Get timeframe from session
        timeframe_hours = session.context.get('timeframe_hours', 48)

        # Get top articles with boost
        conn = sqlite3.connect(curator.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        since_date = (datetime.now() - timedelta(hours=timeframe_hours)).isoformat()

        cursor.execute('''
            SELECT *, 
                   (relevance_score + COALESCE(relevance_boost, 0)) as total_relevance,
                   COALESCE(relevance_boost, 0) as boost_score
            FROM content 
            WHERE added_date > ?
            ORDER BY total_relevance DESC, relevance_score DESC, published_date DESC 
            LIMIT 100
        ''', (since_date,))

        articles = [dict(row) for row in cursor.fetchall()]
        conn.close()

        return jsonify({
            'session_id': session_id,
            'articles': articles,
            'total_found': len(articles),
            'timeframe_hours': timeframe_hours
        })

    except Exception as e:
        return jsonify({'error': f'Articles retrieval error: {str(e)}'}), 500


@app.route('/api/research-agent/chat-about-article', methods=['POST'])
def research_chat_about_article():
    """Enhanced chat about article with full content processing"""
    try:
        data = request.json
        session_id = data.get('session_id')
        article_url = data.get('url', '').strip()
        article_title = data.get('title', '').strip()

        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400

        if not article_url:
            return jsonify({'error': 'Article URL required'}), 400

        # Get or create session
        session = research_assistant.sessions.get(session_id)
        if not session:
            # Create a new session if none exists
            session = research_assistant.ResearchAgentSession(session_id, curator.db_path)
            session.update_state('chat')
            research_assistant.sessions[session_id] = session

        # Use the enhanced article discussion handler
        result = research_assistant._handle_article_discussion_request(
            session, article_url, article_title
        )

        return jsonify({
            'success': True,
            'session_id': session_id,
            'article': {
                'url': article_url,
                'title': article_title,
                'loaded': result.get('article_loaded', False)
            },
            **result  # Include response, actions, state, etc.
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Error preparing article for discussion: {str(e)}'
        }), 500


@app.route('/api/research-agent/force-refresh', methods=['POST'])
def force_refresh_collection():
    """Force a fresh collection cycle, bypassing existing hot topics boost data"""
    try:
        data = request.json
        session_id = data.get('session_id')
        timeframe_hours = data.get('timeframe_hours', 48)
        max_process = data.get('max_process', 25)

        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400

        # Start forced refresh through research assistant
        result = research_assistant.start_forced_refresh(session_id, timeframe_hours)

        if result.get('forced_refresh'):
            # Start collection in background thread with forced refresh
            def run_forced_collection():
                try:
                    # Force hot topics generation by ignoring existing data
                    stats = curator.run_collection_cycle(
                        max_process=max_process,
                        time_range_hours=timeframe_hours,
                        hot_topics_keywords=None  # Will generate fresh
                    )

                    # Generate fresh hot topics and apply rescoring
                    today = datetime.now().strftime("%Y%m%d")
                    hot_topics_files = glob.glob(os.path.join(DATA_DIR, f"current_events_analysis_{today}.json"))

                    if hot_topics_files:
                        latest_file = max(hot_topics_files, key=os.path.getctime)
                        with open(latest_file, 'r', encoding='utf-8') as f:
                            hot_topics_data = json.load(f)

                        keywords = hot_topics_data.get('analysis', {}).get('search_keywords', [])
                        if keywords:
                            rescore_stats = curator.rescore_with_hot_topics(keywords, force_rescore=True)
                            stats.update({
                                'rescore_stats': rescore_stats,
                                'operation_type': 'forced_refresh_with_boost'
                            })

                    stats['forced_refresh'] = True
                    research_assistant.update_collection_stats(session_id, stats)

                except Exception as e:
                    print(f"Forced collection error: {e}")
                    research_assistant.update_collection_stats(session_id, {
                        'error': str(e),
                        'operation_type': 'forced_refresh_error',
                        'forced_refresh': True
                    })

            # Start collection thread
            collection_thread = threading.Thread(target=run_forced_collection, daemon=True)
            collection_thread.start()

        return jsonify({
            'success': True,
            'session_id': session_id,
            'forced_refresh': True,
            'timeframe_hours': timeframe_hours,
            **result
        })

    except Exception as e:
        return jsonify({'error': f'Force refresh error: {str(e)}'}), 500

@app.route('/api/research-agent/hot-topics-status/<date>')
def get_hot_topics_boost_status(date):
    """Get status of hot topics boost scoring for a specific date"""
    try:
        # Validate date format
        try:
            datetime.strptime(date, '%Y-%m-%d')
        except ValueError:
            return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400

        # Get boost status from curator
        boost_status = curator.check_hot_topics_boost_status(date)

        return jsonify({
            'success': True,
            'date': date,
            'boost_status': boost_status
        })

    except Exception as e:
        return jsonify({'error': f'Status check error: {str(e)}'}), 500


@app.route('/api/research-agent/all-articles', methods=['POST'])
def get_all_articles():
    """Get all articles from database for modal filtering"""
    try:
        data = request.json
        session_id = data.get('session_id')
        limit = data.get('limit', 100)

        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400

        # Get articles with boost scores
        conn = sqlite3.connect(curator.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute('''
            SELECT *, 
                   (relevance_score + COALESCE(relevance_boost, 0)) as total_relevance,
                   COALESCE(relevance_boost, 0) as boost_score
            FROM content 
            ORDER BY (relevance_score + COALESCE(relevance_boost, 0)) DESC, published_date DESC 
            LIMIT ?
        ''', (limit,))

        articles = [dict(row) for row in cursor.fetchall()]
        conn.close()

        return jsonify({
            'success': True,
            'session_id': session_id,
            'articles': articles,
            'total_found': len(articles),
            'limit_applied': limit
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Error retrieving articles: {str(e)}'
        }), 500

# ===============================
# ENHANCED DAILY PODCAST ENDPOINTS
# ===============================

@app.route('/api/daily-podcast/start', methods=['POST'])
def start_daily_podcast():
    """Start daily podcast generation with enhanced Edge-TTS support"""
    try:
        data = request.json
        session_id = data.get('session_id')
        chain_context = data.get('chain_context', False)

        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400

        print(f"🚀 Starting enhanced podcast for session: {session_id}")
        
        # Check TTS capabilities
        tts_status = check_dependencies_status()
        print(f"🔧 TTS Status: {tts_status}")
        
        result = podcast_generator.start_podcast_generation(session_id)
        result['tts_capabilities'] = tts_status
        
        print(f"🚀 Start result: {result}")

        return jsonify({
            'success': True,
            'session_id': session_id,
            **result
        })

    except Exception as e:
        return jsonify({'error': f'Failed to start podcast generation: {str(e)}'}), 500


@app.route('/api/daily-podcast/progress/<session_id>')
def get_podcast_progress(session_id):
    """Get progress for podcast generation with enhanced status"""
    try:
        progress_info = podcast_generator.get_progress(session_id)

        if not progress_info:
            return jsonify({'error': 'Session not found'}), 404

        # Add TTS capability info to progress
        progress_info['tts_capabilities'] = check_dependencies_status()

        return jsonify(progress_info)

    except Exception as e:
        return jsonify({'error': f'Progress error: {str(e)}'}), 500


@app.route('/api/daily-podcast/download/<filename>')
def download_podcast(filename):
    """Download generated podcast file with enhanced security"""
    try:
        import os
        from flask import send_file

        # Security: only allow podcast files
        allowed_prefixes = ['podcast_', 'current_events_analysis_']
        if not any(filename.startswith(prefix) for prefix in allowed_prefixes):
            return jsonify({'error': 'Invalid file requested'}), 400

        file_path = os.path.join('data', filename)

        if not os.path.exists(file_path):
            return jsonify({'error': 'File not found'}), 404

        return send_file(file_path, as_attachment=True, download_name=filename)

    except Exception as e:
        return jsonify({'error': f'Download error: {str(e)}'}), 500


@app.route('/api/daily-podcast/status')
def get_podcast_system_status():
    """Get system status for podcast generation capabilities"""
    try:
        status = check_dependencies_status()
        
        # Determine overall TTS capability
        if status['edge_tts'] and status['pydub']:
            tts_level = 'enhanced'
            message = 'Enhanced TTS with distinct voices available'
        elif status['system_tts']:
            tts_level = 'basic'
            message = 'Basic system TTS available'
        else:
            tts_level = 'script_only'
            message = 'TTS not available - script generation only'

        return jsonify({
            'tts_level': tts_level,
            'message': message,
            'capabilities': status,
            'recommendations': _get_tts_recommendations(status)
        })

    except Exception as e:
        return jsonify({'error': f'Status check error: {str(e)}'}), 500


def _get_tts_recommendations(status):
    """Get recommendations for improving TTS capabilities"""
    recommendations = []
    
    if not status['edge_tts']:
        recommendations.append({
            'type': 'install',
            'command': 'pip install edge-tts',
            'description': 'Install edge-tts for high-quality voice synthesis'
        })
    
    if not status['pydub']:
        recommendations.append({
            'type': 'install',
            'command': 'pip install pydub',
            'description': 'Install pydub for audio manipulation and combining'
        })
    
    if status['edge_tts'] and status['pydub']:
        recommendations.append({
            'type': 'success',
            'description': 'All dependencies installed - enhanced TTS ready!'
        })
    elif status['system_tts']:
        recommendations.append({
            'type': 'info',
            'description': 'System TTS available as fallback'
        })
    
    return recommendations


# ===============================
# CORE ENDPOINTS NEEDED BY RESEARCH AGENT
# ===============================

@app.route('/api/progress')
def get_progress():
    """Get operation progress for research agent"""
    progress = curator.get_operation_progress()

    if progress and progress.get('status') == 'running':
        if progress.get('total', 0) > 0:
            progress['percentage'] = round((progress['completed'] / progress['total']) * 100, 1)
        else:
            progress['percentage'] = 0

        elapsed = progress.get('elapsed_seconds', 0)
        mins, secs = divmod(elapsed, 60)
        progress['elapsed_formatted'] = f"{mins}m {secs}s"

        return jsonify(progress)
    else:
        return jsonify({'status': 'idle'})


@app.route('/api/hot-topics')
def get_hot_topics():
    """Get today's hot topics analysis"""
    try:
        today = datetime.now().strftime("%Y%m%d")
        files = glob.glob(os.path.join(DATA_DIR,f"current_events_analysis_{today}_*.json"))

        if not files:
            return jsonify({
                'status': 'no_analysis',
                'message': 'No current events analysis found for today',
                'keywords': [],
                'trending_topics': [],
                'last_analysis': None
            })

        latest_file = max(files, key=os.path.getctime)
        with open(latest_file, 'r', encoding='utf-8') as f:
            data = json.load(f)

        analysis = data.get('analysis', {})

        return jsonify({
            'status': 'success',
            'keywords': analysis.get('search_keywords', [])[:15],
            'trending_topics': analysis.get('trending_topics', [])[:10],
            'summary': analysis.get('summary', ''),
            'last_analysis': analysis.get('analysis_timestamp'),
            'headline_count': data.get('headline_count', 0),
            'sources_analyzed': data.get('sources_analyzed', [])
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Error loading hot topics: {str(e)}',
            'keywords': [],
            'trending_topics': []
        })


@app.route('/api/interests')
def get_interests():
    """Get user interests"""
    try:
        conn = sqlite3.connect(curator.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM user_interests ORDER BY weight DESC')
        interests = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return jsonify(interests)
    except Exception as e:
        return jsonify({'error': f'Error getting interests: {str(e)}'}), 500


@app.route('/api/chat', methods=['POST'])
def chat():
    """General chat endpoint for research agent"""
    try:
        data = request.json
        user_message = data.get('message', '').strip()
        
        if not user_message:
            return jsonify({'error': 'No message provided'}), 400
        
        response = chat_assistant.generate_response(user_message)
        
        return jsonify({'response': response})
    except Exception as e:
        return jsonify({'error': f'Chat error: {str(e)}'}), 500


@app.route('/api/chat-about-article', methods=['POST'])
def chat_about_article():
    """Chat about a specific article"""
    try:
        data = request.json
        article_url = data.get('url', '').strip()
        
        if not article_url:
            return jsonify({'error': 'No article URL provided'}), 400

        article_info = chat_assistant.get_article_for_chat(article_url)
        if 'error' in article_info:
            return jsonify({'error': article_info['error']}), 404

        if article_info.get('needs_summary', False):
            try:
                content_dict = {
                    'title': article_info['title'],
                    'source': article_info['source'],
                    'url': article_info['url'],
                    'content': article_info['content']
                }

                summary, relevance_score = curator.generate_summary_with_lock(content_dict)

                article_info.update({
                    'ai_summary': summary,
                    'relevance_score': relevance_score,
                    'has_ai_summary': True,
                    'chat_intro': f"I've analyzed this article: **{article_info['title']}** from {article_info['source']}\n\n**AI Summary:** {summary}\n\n**Relevance Score:** {relevance_score:.1f}/10\n\nWhat would you like to know or discuss about this article?"
                })
            except Exception as e:
                article_info['chat_intro'] = f"I'm having trouble generating a summary for this article: **{article_info['title']}** from {article_info['source']}\n\nHere's the original content to discuss:\n\n{article_info['content'][:500]}...\n\nWhat would you like to know about this article?"

        return jsonify({
            'success': True,
            'article': {
                'title': article_info['title'],
                'source': article_info['source'],
                'url': article_info['url'],
                'published_date': article_info['published_date'],
                'has_ai_summary': article_info['has_ai_summary'],
                'ai_summary': article_info.get('ai_summary', ''),
                'relevance_score': article_info.get('relevance_score', 0),
                'chat_intro': article_info['chat_intro']
            }
        })

    except Exception as e:
        return jsonify({'error': f'Error preparing article for chat: {str(e)}'}), 500


@app.route('/api/research-agent/check-existing-results', methods=['POST'])
def check_existing_results():
    """Check if quality research results exist for today"""
    try:
        data = request.json
        session_id = data.get('session_id')

        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400

        # Check boost status for today
        today_date = datetime.now().strftime('%Y-%m-%d')
        boost_status = curator.check_hot_topics_boost_status(today_date)

        # Return whether quality threshold is met
        has_quality_results = (
                boost_status.get('has_boost_scoring', False) and
                boost_status.get('quality_threshold_met', False)
        )

        return jsonify({
            'success': True,
            'has_existing_results': has_quality_results,
            'boost_status': boost_status
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Error checking existing results: {str(e)}'
        }), 500

# ===============================
# LEGACY ENDPOINTS (PRESERVED)
# ===============================

@app.route('/api/content')
def get_content():
    """Get content - simplified for research agent"""
    try:
        hours = int(request.args.get('hours', 24))
        limit = int(request.args.get('limit', 20))
        min_relevance = float(request.args.get('min_relevance', 0.0))

        results = curator.get_recent_content(
            hours=hours,
            limit=limit,
            min_relevance=min_relevance
        )

        return jsonify(results)

    except Exception as e:
        print(f"Error in get_content: {e}")
        return jsonify([]), 500


@app.route('/api/pdf/check-capabilities')
def check_pdf_capabilities():
    """Check PDF processing capabilities"""
    try:
        if HAS_PDF_SUPPORT:
            capabilities = get_pdf_capabilities()
            return jsonify({
                'success': True,
                'pdf_support': True,
                'capabilities': capabilities
            })
        else:
            return jsonify({
                'success': True,
                'pdf_support': False,
                'message': 'PDF processing module not available',
                'recommendations': [
                    'Ensure pdf_parser.py is in the project directory',
                    'Install dependencies: pip install pdfplumber PyPDF2 pymupdf'
                ]
            })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Error checking PDF capabilities: {str(e)}'
        }), 500


@app.route('/api/pdf/is-pdf-url', methods=['POST'])
def check_is_pdf_url():
    """Check if a URL points to a PDF"""
    try:
        data = request.json
        url = data.get('url', '').strip()

        if not url:
            return jsonify({'error': 'URL required'}), 400

        if not HAS_PDF_SUPPORT:
            return jsonify({
                'is_pdf': False,
                'error': 'PDF processing not available'
            })

        is_pdf = is_pdf_url(url)

        return jsonify({
            'success': True,
            'url': url,
            'is_pdf': is_pdf
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Error checking URL: {str(e)}'
        }), 500


@app.route('/api/pdf/process', methods=['POST'])
def process_pdf_endpoint():
    """Process a PDF URL and extract text"""
    try:
        data = request.json
        url = data.get('url', '').strip()
        title = data.get('title', '').strip() or None

        if not url:
            return jsonify({'error': 'PDF URL required'}), 400

        if not HAS_PDF_SUPPORT:
            return jsonify({
                'success': False,
                'error': 'PDF processing not available. Install pdf_parser.py and dependencies.'
            }), 503

        # Process the PDF
        result = process_pdf(url, title)

        return jsonify({
            'success': True,
            'result': result
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'PDF processing error: {str(e)}'
        }), 500


@app.route('/api/pdf/process-for-chat', methods=['POST'])
def process_pdf_for_chat():
    """Process PDF for research agent chat integration"""
    try:
        data = request.json
        session_id = data.get('session_id')
        url = data.get('url', '').strip()
        title = data.get('title', '').strip() or None

        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400

        if not url:
            return jsonify({'error': 'PDF URL required'}), 400

        if not HAS_PDF_SUPPORT:
            return jsonify({
                'success': False,
                'error': 'PDF processing not available'
            }), 503

        # Process the PDF
        pdf_result = process_pdf(url, title)

        if not pdf_result['success']:
            return jsonify({
                'success': False,
                'error': pdf_result['error']
            })

        # Format for research agent
        chat_intro = f"""📄 **PDF Document Analysis Complete**

**Title:** {pdf_result['title']}
**Source:** {pdf_result['source']}
**Content Length:** {pdf_result['content_length']:,} characters
**Extraction Method:** {pdf_result['extraction_method']}

**Document Content Preview:**
{pdf_result['content'][:500]}...

I've successfully extracted and analyzed this PDF. What would you like to discuss about it?"""

        # Prepare article data structure compatible with research agent
        article_data = {
            'title': pdf_result['title'],
            'source': pdf_result['source'],
            'url': pdf_result['url'],
            'content': pdf_result['content'],
            'content_type': 'pdf',
            'published_date': pdf_result['published_date'],
            'chat_intro': chat_intro,
            'extraction_method': pdf_result['extraction_method'],
            'content_length': pdf_result['content_length']
        }

        return jsonify({
            'success': True,
            'session_id': session_id,
            'article': article_data,
            'pdf_result': pdf_result
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'PDF chat processing error: {str(e)}'
        }), 500

@app.route('/api/system-status')
def get_system_status():
    """Enhanced system status including PDF capabilities"""
    try:
        # Check core components
        status = {
            'database': True,  # Your existing checks
            'ollama': True,  # Your existing checks
            'content_curator': True,
            'pdf_support': HAS_PDF_SUPPORT
        }

        if HAS_PDF_SUPPORT:
            status['pdf_capabilities'] = get_pdf_capabilities()

        return jsonify({
            'success': True,
            'status': status
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Status check error: {str(e)}'
        }), 500

# ===============================
# MAIN APPLICATION STARTUP
# ===============================

if __name__ == '__main__':
    print("Starting Enhanced Research Assistant Agent with Edge-TTS...")
    print("Features: Auto-collection, Hot Topics, Internet Search, Chat, Enhanced Podcasts")
    
    # Check TTS capabilities on startup
    tts_status = check_dependencies_status()
    print(f"🔧 TTS Capabilities: {tts_status}")
    
    if tts_status['edge_tts'] and tts_status['pydub']:
        print("✅ Enhanced TTS with distinct voices available!")
    elif tts_status['system_tts']:
        print("⚠️ Basic system TTS available (install edge-tts + pydub for enhanced audio)")
    else:
        print("❌ No TTS available - podcast will generate scripts only")
        print("   Install with: pip install edge-tts pydub")
    
    print("Make sure Ollama is running with granite3.2:8b model installed")
    print("\nResearch Agent available at http://localhost:5000")
    print("Now includes enhanced podcast generation with distinct voices!")
    print("\nPress Ctrl+C to stop")

    import logging
    logging.getLogger('werkzeug').setLevel(logging.ERROR)

    # Check if we have content, run initial collection if needed
    conn = sqlite3.connect(curator.db_path)
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) FROM content')
    count = cursor.fetchone()[0]
    conn.close()

    if count == 0:
        print("\nNo content found. Running initial collection...")
        try:
            curator.run_collection_cycle()
        except Exception as e:
            print(f"Initial collection failed: {e}")

    app.run(debug=True, port=5000, use_reloader=False)